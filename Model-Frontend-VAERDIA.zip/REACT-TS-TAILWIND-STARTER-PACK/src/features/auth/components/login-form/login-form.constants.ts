import { FormConfig } from "@/types/interfaces/form-config"

import { APP_CONFIG } from "@/config/constants/app.constants"

import { LoginFormType } from "../../schemas/login-form.schema"

export const LOGIN_FORM_CONFIG: FormConfig<LoginFormType> = {
  email: {
    name: "email",
    label: "auth.email",
    placeholder: "auth.email_placeholder",
    defaultValue: APP_CONFIG.EmptyString,
    disabled: false,
    isRequired: true,
  },
  password: {
    name: "password",
    label: "auth.password",
    placeholder: "auth.password_placeholder",
    defaultValue: APP_CONFIG.EmptyString,
    description: "auth.password_description",
    disabled: false,
    isRequired: true,
  },
  userName: {
    name: "userName",
    label: "auth.user_name",
    placeholder: "auth.user_name_placeholder",
    description: "auth.user_name_description",
    defaultValue: APP_CONFIG.EmptyString,
    disabled: false,
    isRequired: false,
  },
  gender: {
    name: "gender",
    label: "Genre",
    placeholder: "Choisissez votre genre",
    isRequired: true,
  },
  dateOfBirth: {
    name: "dateOfBirth",
    label: "Date de naissance",
    isRequired: true,
    placeholder: "Choisissez votre date de naissance",
  },
}
