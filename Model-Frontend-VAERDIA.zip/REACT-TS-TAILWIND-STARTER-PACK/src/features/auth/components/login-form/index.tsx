import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { useTranslation } from "react-i18next"

import { useToast } from "@/hooks/use-toast"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Form } from "@/components/ui/form"

import LoadingButton from "@/components/buttons/loading-button"
import DateInput from "@/components/inputs/date-input"
import EmailInput from "@/components/inputs/email-input"
import PasswordInput from "@/components/inputs/password-input"
import SelectInput from "@/components/inputs/select-input"
import TextInput from "@/components/inputs/text-input"

import useLogin from "../../api/use-login"
import { LoginFormType, loginFormSchema } from "../../schemas/login-form.schema"
import { LOGIN_FORM_CONFIG } from "./login-form.constants"

export default function LoginForm() {
  const { t } = useTranslation()

  // Mutation
  const { mutate, isPending } = useLogin()

  const { toast } = useToast()

  const loginForm = useForm<LoginFormType>({
    mode: "onChange",
    shouldFocusError: true,
    resolver: zodResolver(loginFormSchema),
  })

  const onSubmit = loginForm.handleSubmit((data) => {
    toast({
      title: "Data",
      description: (
        <pre className="mt-2 w-[340px] rounded-md bg-slate-950 p-4">
          <code className="text-white">{JSON.stringify(data, null, 2)}</code>
        </pre>
      ),
    })

    // TODO: Delete the return statement
    return
    mutate(data)
  })

  return (
    <Form {...loginForm}>
      <Card className="w-[400px]">
        <CardHeader>
          <CardTitle className="text-center text-2xl">
            {t("auth.login")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          <TextInput config={LOGIN_FORM_CONFIG.userName} type="text" />
          <EmailInput config={LOGIN_FORM_CONFIG.email} />
          <PasswordInput config={LOGIN_FORM_CONFIG.password} />
          <DateInput config={LOGIN_FORM_CONFIG.dateOfBirth} />
          <SelectInput
            config={LOGIN_FORM_CONFIG.gender}
            options={[
              {
                label: "Homme",
                value: "male",
              },
              {
                label: "Femme",
                value: "female",
              },
            ]}
          />
        </CardContent>
        <CardFooter className="flex flex-col gap-y-2">
          <LoadingButton
            label="auth.login"
            isLoading={isPending}
            onClick={onSubmit}
          />
          <Button className="w-full" variant="outline">
            {t("auth.register")}
          </Button>
        </CardFooter>
      </Card>
    </Form>
  )
}
