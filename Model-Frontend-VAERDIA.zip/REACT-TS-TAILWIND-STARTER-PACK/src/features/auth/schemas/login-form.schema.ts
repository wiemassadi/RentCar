import { z } from "zod"

export const loginFormSchema = z.object({
  userName: z
    .string({
      required_error: "auth.formValidation.user_name_required",
    })
    .min(3, {
      message: "auth.formValidation.user_name_too_short",
    })
    .max(50, {
      message: "auth.formValidation.user_name_too_long",
    }),

  email: z
    .string({ required_error: "auth.formValidation.email_required" })
    .email({
      message: "auth.formValidation.email_invalid",
    })
    .min(1, {
      message: "auth.formValidation.email_required",
    })
    .max(255, {
      message: "auth.formValidation.email_too_long",
    })
    .trim(),

  password: z
    .string({
      required_error: "auth.formValidation.password_required",
    })
    .min(8, {
      message: "auth.formValidation.password_too_short",
    })
    .max(255, {
      message: "auth.formValidation.password_too_long",
    }),
  gender: z.enum(["male", "female"], {
    required_error: "Genre est obligatoire",
    message: "Genre est obligatoire",
  }),
  dateOfBirth: z.date({
    required_error: "Date de naissance est obligatoire",
    message: "Date de naissance est obligatoire",
  }),
})

export type LoginFormType = z.infer<typeof loginFormSchema>
