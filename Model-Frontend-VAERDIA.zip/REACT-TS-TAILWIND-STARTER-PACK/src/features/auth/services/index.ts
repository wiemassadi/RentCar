import { User } from "@/types/models/user"

import { ENDPOINTS } from "@/config/constants/endpoints.constans"

import axiosClient from "@/lib/axios"

import { LoginFormType } from "../schemas/login-form.schema"

export const login = async (data: LoginFormType): Promise<User> => {
  const user = (await axiosClient.post<User>(ENDPOINTS.Auth.Login, data)).data

  return user
}
