import { useMutation } from "@tanstack/react-query"
import { AxiosError } from "axios"
import { useNavigate } from "react-router-dom"

import i18nInstance from "@/locales/i18n"

import { User } from "@/types/models/user"

import { ROUTER_PATHS } from "@/config/constants/paths.constants"
import { LocalStorageKeysEnum } from "@/config/enums/local-storage.enum"

import { useToast } from "@/hooks/use-toast"

import { persistData } from "@/helpers/local-storage.helpers"

import { LoginFormType } from "../schemas/login-form.schema"
import { login } from "../services"

export default function useLogin() {
  const navigate = useNavigate()
  const { toast } = useToast()

  const mutation = useMutation<User, AxiosError, LoginFormType>({
    mutationKey: ["login"],
    mutationFn: login,
    onSuccess: (data) => {
      persistData(LocalStorageKeysEnum.User, data)
      persistData(LocalStorageKeysEnum.Token, data.accessToken)
      navigate(ROUTER_PATHS.DashboardPaths.DashboardRootPath)
      toast({
        title: i18nInstance.t("auth.login_success"),
        variant: "success",
      })
    },
    onError: () => {
      toast({
        title: i18nInstance.t("auth.login_error"),
        variant: "destructive",
      })
    },
  })

  return mutation
}
