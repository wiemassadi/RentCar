import { useQuery } from "@tanstack/react-query"
import { AxiosError } from "axios"

import { Paginator } from "@/types/interfaces/paginator"
import {
  PaginationApiResponse,
  PaginationResponse,
} from "@/types/models/pagination"
import { Project, ProjectApi } from "@/types/models/project"

import axiosClient from "@/lib/axios"

import {
  transformPaginationIntoQueryParams,
  transformPaginationResponse,
} from "@/helpers/pagination.helpers"

export default function (paginator: Paginator) {
  const query = useQuery<PaginationResponse<Project>, AxiosError>({
    queryKey: ["projects", { paginator }],
    queryFn: async () => {
      const apiResponse = (
        await axiosClient.get<PaginationApiResponse<ProjectApi>>(
          transformPaginationIntoQueryParams("getTest", paginator)
        )
      ).data

      const data: PaginationResponse<Project> = {
        ...transformPaginationResponse(apiResponse),
        data: apiResponse.data.map((project) => ({
          id: project.id,
          address: project.address,
          building: project.building,
          canDelete: project.can_delete,
          canUpdate: project.can_update,
          city: project.city,
          commune: project.commune,
          door: project.door,
          downloadSignature: project.download_signature,
          emailAnah: project.email_anah,
          emailContact: project.email_contact,
          firstName: project.first_name,
          floor: project.floor,
          houseNumber: project.house_number,
          lastName: project.last_name,
          numberUnbornChildren: project.number_unborn_children,
          passwordAnah: project.password_anah,
          phoneNumber1: project.phone_number_1,
          phoneNumber2: project.phone_number_2,
          position: project.position,
          reference: project.reference,
          representative: project.representative,
          representativeContact: project.representative_contact,
          signature: project.signature,
          stairs: project.stairs,
          state: project.state,
          street: project.street,
          yearOfBirth: project.year_of_birth,
          zipCode: project.zip_code,
        })),
      }

      return data
    },
  })

  return query
}
