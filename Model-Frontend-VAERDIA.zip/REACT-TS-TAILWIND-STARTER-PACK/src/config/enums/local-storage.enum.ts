export enum LocalStorageKeysEnum {
  User = "user",
  Token = "token",
  RememberMe = "rememberMe",
}
