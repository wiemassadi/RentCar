export enum RoutesEnum {
  Root = "",
  Any = "*",
  NotFound = "404",
  Restricted = "restricted",
  Forbidden = "forbidden",
  Id = ":id",
  Home = "home",

  Add = "add",
  Edit = "edit",
  EditId = "edit/:id",

  // Aut Routes
  Auth = "auth",
  Login = "login",
  ForgotPassword = "forgot-password",

  // Dashboard Routes
  Dashboard = "dashboard",
  Articles = "articles",
  Clients = "clients",
}
