export enum LanguageShortLabelsEnum {
  English = "en",
  French = "fr",
}

export enum LanguageLongLabelsEnum {
  English = "en-US",
  French = "fr-FR",
}
