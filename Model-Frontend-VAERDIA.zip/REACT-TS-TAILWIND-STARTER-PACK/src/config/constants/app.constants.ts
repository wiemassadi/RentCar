export const APP_CONFIG = {
  EmptyString: "",
  NO_PLACEHOLDER: "",

  // React Query Client config
  QueryClient: {
    RetryDelay: 1000,
    Retry: 3,
    RefetchOnWindowFocus: false,
    StaleTime: 60000,
  },

  // Debounce
  DebounceTiming: {
    Short: 500,
    Medium: 700,
    Long: 1000,
    TooLong: 3000,
  },

  Pagination: {
    FirstPage: 1,
    ElementsPerPage: {
      Min: 25,
      Medium: 50,
      Max: 75,
    },
  },

  Date: {
    Format: {
      ReadableFullDate: "PPP",
    },
  },
}
