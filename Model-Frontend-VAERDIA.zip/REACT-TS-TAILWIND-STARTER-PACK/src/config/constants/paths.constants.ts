import { joinPaths } from "@/helpers/path.helpers"

import { RoutesEnum } from "../enums/routes.enum"

export const ROUTER_PATHS = {
  AuthPaths: {
    LoginPath: joinPaths([RoutesEnum.Root, RoutesEnum.Auth, RoutesEnum.Login]),
    ForgetPasswordPath: joinPaths([
      RoutesEnum.Root,
      RoutesEnum.Auth,
      RoutesEnum.ForgotPassword,
    ]),
  },

  DashboardPaths: {
    DashboardRootPath: joinPaths([
      RoutesEnum.Root,
      RoutesEnum.Dashboard,
      RoutesEnum.Home,
    ]),

    // TODO: This is just an example, I recommend to delete it if you don't need it
    ClientsPaths: {
      List: joinPaths([
        RoutesEnum.Root,
        RoutesEnum.Dashboard,
        RoutesEnum.Clients,
      ]),
      Add: joinPaths([
        RoutesEnum.Root,
        RoutesEnum.Dashboard,
        RoutesEnum.Clients,
        RoutesEnum.Add,
      ]),
    },

    ArticlesPaths: {
      List: joinPaths([
        RoutesEnum.Root,
        RoutesEnum.Dashboard,
        RoutesEnum.Articles,
      ]),

      Add: joinPaths([
        RoutesEnum.Root,
        RoutesEnum.Dashboard,
        RoutesEnum.Articles,
        RoutesEnum.Add,
      ]),
    },
  },
}
