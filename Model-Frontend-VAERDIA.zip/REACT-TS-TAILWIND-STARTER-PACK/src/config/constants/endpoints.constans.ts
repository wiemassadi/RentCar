export const ENDPOINTS = {
  Auth: {
    Login: "login",
  },
}
