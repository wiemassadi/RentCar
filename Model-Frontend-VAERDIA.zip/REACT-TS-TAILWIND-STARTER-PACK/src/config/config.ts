export const CONFIG = {
  APP_NAME: import.meta.env.VITE_APP_NAME ?? "Starter App",
  LOCAL_STORAGE_SECRET_KEY:
    import.meta.env.VITE_LOCAL_STORAGE_SECRET_KEY ?? "LocalStorageEncryption",
  ENDPOINT_BASE_URL:
    import.meta.env.VITE_ENDPOINT_BASE_URL ?? "http://localhost:8000/api",
  VAERDIA_WEBSITE_URL: "https://www.vaerdia.com/",
}
