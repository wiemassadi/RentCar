import { Navigate } from "react-router-dom"

import { User } from "@/types/models/user"

import { ROUTER_PATHS } from "@/config/constants/paths.constants"
import { LocalStorageKeysEnum } from "@/config/enums/local-storage.enum"

import { getPersistedData } from "@/helpers/local-storage.helpers"

export default function AuthGuard({ children }: { children: React.ReactNode }) {
  const user = getPersistedData<User>(LocalStorageKeysEnum.User, true)

  if (!user) return <Navigate to={ROUTER_PATHS.AuthPaths.LoginPath} replace />

  return children
}
