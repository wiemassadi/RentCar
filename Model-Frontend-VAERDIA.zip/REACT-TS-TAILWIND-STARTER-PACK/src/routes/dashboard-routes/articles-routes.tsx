import { lazy } from "react"

import { RouteObject } from "react-router-dom"

import { RoutesEnum } from "@/config/enums/routes.enum"

const ArticlesListPage = lazy(() => import("@/pages/articles/articles-list"))
const AddNewArticlePage = lazy(() => import("@/pages/articles/add-new-article"))

export const articlesRoutes: RouteObject = {
  path: RoutesEnum.Articles,
  element: null,
  children: [
    {
      path: RoutesEnum.Root,
      element: <ArticlesListPage />,
    },
    { path: RoutesEnum.Add, element: <AddNewArticlePage /> },
  ],
}
