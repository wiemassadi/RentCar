import { lazy } from "react"

import { Navigate, RouteObject } from "react-router-dom"

import { RoutesEnum } from "@/config/enums/routes.enum"

import DashboardLayout from "@/layouts/dahboard-layout"

import AuthGuard from "@/guards/auth-guard"

import { articlesRoutes } from "./articles-routes"

const DashboardPage = lazy(() => import("@/pages/dashboard"))

export const dashboardRoutes: RouteObject = {
  path: RoutesEnum.Dashboard,
  element: (
    <AuthGuard>
      <DashboardLayout />
    </AuthGuard>
  ),
  children: [
    {
      path: RoutesEnum.Root,
      element: <Navigate to={RoutesEnum.Home} />,
    },
    {
      path: RoutesEnum.Home,
      element: <DashboardPage />,
    },
    articlesRoutes,
  ],
}
