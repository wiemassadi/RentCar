import { useRoutes } from "react-router-dom"

import { routesConfig } from "./routes-config"

export default function Router() {
  return useRoutes(routesConfig)
}
