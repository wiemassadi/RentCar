import { Navigate, RouteObject } from "react-router-dom"

import { RoutesEnum } from "@/config/enums/routes.enum"

import { authRoutes } from "./auth-routes"
import { dashboardRoutes } from "./dashboard-routes"

export const routesConfig: RouteObject[] = [
  {
    path: RoutesEnum.Root,
    element: <Navigate to={RoutesEnum.Dashboard} />,
  },
  authRoutes,
  dashboardRoutes,
  {
    path: RoutesEnum.Any,
    // TODO: Create a 404 page
    element: <div>404</div>,
  },
]
