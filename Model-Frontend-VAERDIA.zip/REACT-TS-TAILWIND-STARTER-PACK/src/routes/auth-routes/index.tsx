import { lazy } from "react"

import { RouteObject } from "react-router-dom"

import { RoutesEnum } from "@/config/enums/routes.enum"

import AuthLayout from "@/layouts/auth-layout"

const LoginPage = lazy(() => import("@/pages/auth/login"))
const ForgotPasswordPage = lazy(() => import("@/pages/auth/forgot-password"))

export const authRoutes: RouteObject = {
  path: RoutesEnum.Auth,
  element: <AuthLayout />,
  children: [
    {
      path: RoutesEnum.Login,
      element: <LoginPage />,
    },
    {
      path: RoutesEnum.ForgotPassword,
      element: <ForgotPasswordPage />,
    },
  ],
}
