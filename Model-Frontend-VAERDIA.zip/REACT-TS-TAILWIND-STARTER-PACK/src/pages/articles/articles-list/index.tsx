export default function ArticlesListPage() {
  return <div>Articles List Page</div>
}
