export default function AddNewArticle() {
  return <div>Add New Article</div>
}
