import { useEffect } from "react"

import { useAppGlobalStore } from "@/store/app-global-store"

import LoginForm from "@/features/auth/components/login-form"

export default function LoginPage() {
  const { setConfig, resetConfig } = useAppGlobalStore()

  useEffect(() => {
    setConfig({
      pageTitle: "auth.login",
      breadCrumbs: [],
    })

    return () => {
      resetConfig()
    }
  }, [resetConfig, setConfig])

  return <LoginForm />
}
