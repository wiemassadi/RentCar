export default function ForgotPasswordPage() {
  return <div>Forgot Password Page</div>
}
