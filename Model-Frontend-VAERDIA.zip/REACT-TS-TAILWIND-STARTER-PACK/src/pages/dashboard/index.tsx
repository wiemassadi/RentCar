import { useEffect } from "react"

import { MoreHorizontal } from "lucide-react"

import { Paginator } from "@/types/interfaces/paginator"
import { Project } from "@/types/models/project"

import { APP_CONFIG } from "@/config/constants/app.constants"

import useDebounce from "@/hooks/use-debounce"
import usePagination from "@/hooks/use-pagination"
import useTable from "@/hooks/use-table"

import { useAppGlobalStore } from "@/store/app-global-store"

import useGetProjects from "@/features/dashboard/api/use-get-projects"

import { Card } from "@/components/ui/card"

import IconButton from "@/components/buttons/icon-button"
import DataView from "@/components/data-view"

export default function DashboardPage() {
  const { setConfig, resetConfig } = useAppGlobalStore()

  const paginationMethods = usePagination()

  const debouncedPaginator = useDebounce<Paginator>(
    paginationMethods.paginator,
    APP_CONFIG.DebounceTiming.Medium
  )

  const { data, isFetching } = useGetProjects(debouncedPaginator)

  const table = useTable<Project>({
    paginationResponse: data,
    rowsPerPage: paginationMethods.paginator.rowsPerPage,
    columns: [
      {
        accessorKey: "firstName",
        header: "First Name",
      },
      {
        accessorKey: "lastName",
        header: "Last Name",
      },
      {
        accessorKey: "emailContact",
        header: "Email ",
      },
      {
        accessorKey: "yearOfBirth",
        header: "Date Of Birth",
      },
      {
        accessorKey: "city",
        header: "City",
      },
      {
        accessorKey: "phoneNumber1",
        header: "Phone Number",
      },
      {
        header: "Actions",
        cell: () => (
          <IconButton title="" onClick={() => {}} icon={MoreHorizontal} />
        ),
      },
    ],
  })

  const renderProjectCard = (project: Project) => (
    <Card className="text-xl text-red-500">{project.lastName}</Card>
  )

  useEffect(() => {
    setConfig({
      breadCrumbs: [],
      pageTitle: "dashboard.dashboard_page_title",
    })

    return () => {
      resetConfig()
    }
  }, [setConfig, resetConfig])

  return (
    <DataView
      data={data?.data}
      table={table}
      isFetching={isFetching}
      searchTextPlaceholder="Rechercher des projets..."
      paginatorMethods={paginationMethods}
      totalPages={data?.lastPage}
      renderCard={renderProjectCard}
      renderFilters={() => <div>Project Filters</div>}
      onAddClick={() => {}}
      onDownloadClick={() => {}}
    />
  )
}
