export type InputConfig = {
  name: string
  label: string
  placeholder: string
  description?: string
  defaultValue?: string | number | Date | boolean | string[]
  disabled?: boolean
  isRequired?: boolean
}

export type InputOption = {
  label: string
  value: string
}
