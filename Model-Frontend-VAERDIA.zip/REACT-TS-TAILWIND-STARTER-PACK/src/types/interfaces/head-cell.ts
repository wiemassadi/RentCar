export type HeadCell = {
  id: string
  title: string
  width?: string | number
  align?: "center" | "left" | "right" | "justify" | "inherit"
  isSortable?: boolean
}
