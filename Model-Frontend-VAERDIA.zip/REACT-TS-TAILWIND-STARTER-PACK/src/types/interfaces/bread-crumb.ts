export type BreadCrumbItem = {
  label: string
  path?: string
}
