export type GenericInputConfig<T> = {
  name: keyof T
  label: string
  placeholder: string
  description?: string
  defaultValue?: string | number | Date | boolean | string[]
  disabled?: boolean
  isRequired?: boolean
}

export type FormConfig<T> = Record<keyof T, GenericInputConfig<T>>
