export type Paginator = {
  page: number
  rowsPerPage: number
  search: string
  paginated?: boolean
  orderBy?: string
  orderType?: "asc" | "desc"
  // TODO : Add Filters type
}

export type PaginatorMethods = {
  paginator: Paginator
  changePage: (page: number) => void
  changeSearchText: (searchText: string) => void
  changeOrderBy: (orderBy: string) => void
  changeRowsPerPage: (rowsPerPage: number) => void
  resetPaginator: () => void
  // TODO : Add changeFilters method
}
