export type PaginationApiResponse<T> = {
  data: T[]
  current_page: number
  last_page: number
  per_page: number
  total: number
}

export type PaginationResponse<T> = {
  data: T[]
  currentPage: number
  lastPage: number
  perPage: number
  total: number
}
