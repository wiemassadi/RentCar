export type User = {
  id: number
  name: string
  email: string
  profilePicture: string
  accessToken: string
}
