export type Project = {
  id: number
  firstName: string
  lastName: string
  reference: string
  position: string | null
  city: string
  zipCode: string
  address: string
  houseNumber: string
  street: string
  representativeContact: string | null
  signature: string | null
  phoneNumber1: string
  phoneNumber2: string | null
  emailContact: string
  representative: string | null
  state: number
  yearOfBirth: string
  numberUnbornChildren: number | null
  building: string | null
  emailAnah: string
  passwordAnah: string | null
  stairs: string | null
  floor: string | null
  door: string | null
  canDelete: boolean
  canUpdate: boolean
  commune: string
  downloadSignature: string | null
}

export type ProjectApi = {
  id: number
  first_name: string
  last_name: string
  reference: string
  position: string | null
  city: string
  zip_code: string
  address: string
  house_number: string
  street: string
  representative_contact: string | null
  signature: string | null
  phone_number_1: string
  phone_number_2: string | null
  email_contact: string
  representative: string | null
  state: number
  year_of_birth: string
  number_unborn_children: number | null
  building: string | null
  email_anah: string
  password_anah: string | null
  stairs: string | null
  floor: string | null
  door: string | null
  can_delete: boolean
  can_update: boolean
  commune: string
  download_signature: string | null
}
