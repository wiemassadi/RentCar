import DashboardContent from "./dashboard-content"
import DashboardSideBar from "./dashboard-sidebar"
import DashboardTopBar from "./dashboard-top-bar"

export default function DashboardLayout() {
  return (
    <div className="flex min-h-screen w-full flex-col font-poppins">
      <DashboardTopBar />
      <div className="grid flex-grow grid-cols-1 md:grid-cols-[auto_1fr]">
        <DashboardSideBar />
        <DashboardContent />
      </div>
    </div>
  )
}
