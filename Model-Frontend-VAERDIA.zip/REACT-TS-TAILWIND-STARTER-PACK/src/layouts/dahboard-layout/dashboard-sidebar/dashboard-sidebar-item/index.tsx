import { ChevronDown } from "lucide-react"
import { useTranslation } from "react-i18next"
import { useNavigate } from "react-router-dom"

import { APP_CONFIG } from "@/config/constants/app.constants"

import { cn } from "@/lib/utils"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import Hint from "@/components/hint"

import { DashboardSidebarItemProps } from "./dashboard-sidebar-item.type"

export default function DashboardSidebarItem({
  item,
  isActive,
  expanded,
  onExpand,
  onOpenPopover,
}: DashboardSidebarItemProps) {
  const { t } = useTranslation()
  const navigate = useNavigate()

  const { open, openMobile } = useDashboardSidebarStore()

  const onItemClick = () => {
    if (item.subItems) {
      onExpand?.()
    } else {
      navigate(item.path)
    }
  }

  return (
    <Hint
      title={
        !open && !item.subItems && !openMobile
          ? t(item.label)
          : APP_CONFIG.EmptyString
      }
      side="right"
    >
      <li
        className={cn(
          "group my-1 flex h-9 cursor-pointer items-center justify-between overflow-hidden rounded-md px-2 text-app-gray-500 hover:bg-app-secondary-light hover:text-app-secondary-main",
          isActive &&
            "bg-app-secondary-main text-white hover:bg-app-secondary-main hover:text-white"
        )}
        onClick={onItemClick}
        onMouseEnter={() => {
          if (!open) {
            onOpenPopover?.()
          }
        }}
      >
        <div className="flex items-center justify-start gap-x-4">
          <item.icon
            className={cn(
              "size-4 shrink-0 transition-transform duration-200 ease-in-out group-hover:translate-x-2",
              !open && "ml-[2px] group-hover:translate-x-0"
            )}
          />
          <span
            className={cn(
              "text-sm font-medium text-app-gray-600 transition-transform duration-200 ease-in-out group-hover:translate-x-2 group-hover:text-app-secondary-main",
              isActive && "text-white group-hover:text-white",
              !open && "group-hover:translate-x-0"
            )}
          >
            {t(item.label)}
          </span>
        </div>
        {item.subItems && (
          <ChevronDown
            className={cn(
              "size-4 transition-transform",
              expanded && "rotate-180"
            )}
          />
        )}
      </li>
    </Hint>
  )
}
