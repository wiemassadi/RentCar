import { SidebarItem } from "../dashboard-sidebar.type"

export type DashboardSidebarItemProps = {
  item: SidebarItem
  isActive: boolean
  expanded?: boolean
  onExpand?: () => void
  onOpenPopover?: () => void
}
