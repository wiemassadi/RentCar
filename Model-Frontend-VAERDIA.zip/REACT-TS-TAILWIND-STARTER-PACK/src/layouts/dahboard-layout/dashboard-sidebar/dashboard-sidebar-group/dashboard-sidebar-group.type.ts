import { SidebarGroup } from "../dashboard-sidebar.type"

export type DashboardSidebarGroupProps = {
  group: SidebarGroup
}
