import { useEffect } from "react"

import { useTranslation } from "react-i18next"
import { useLocation } from "react-router-dom"

import { BreakpointsEnum } from "@/config/enums/breakpoints.enum"

import { cn } from "@/lib/utils"

import useResponsive from "@/hooks/use-responsive"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import { checkPathIsActive } from "@/helpers/path.helpers"

import Typography from "@/components/typography"

import DashboardSidebarCollapsibleItem from "../dashboard-sidebar-collapsible-item"
import DashboardSidebarItem from "../dashboard-sidebar-item"
import { DashboardSidebarGroupProps } from "./dashboard-sidebar-group.type"

export default function DashboardSidebarGroup({
  group,
}: DashboardSidebarGroupProps) {
  const { t } = useTranslation()
  const { pathname } = useLocation()

  const { open, openMobile, toggleSidebar, setIsMobile } =
    useDashboardSidebarStore()

  const isTablet = useResponsive("down", BreakpointsEnum.Lg)
  const isDesktop = useResponsive("up", BreakpointsEnum.Lg)

  // Close the sidebar when the screen is  desktop
  useEffect(() => {
    if (isTablet) {
      toggleSidebar(false)
      setIsMobile(true)
    }

    if (isDesktop) {
      toggleSidebar(true)
    }
  }, [isTablet, isDesktop, toggleSidebar, setIsMobile])

  return (
    <div className="space-y-2 py-4">
      <Typography
        variant="h5"
        muted
        className={cn(
          "uppercase",
          (!group.title || !open) && "hidden",
          openMobile && "block"
        )}
      >
        {t(group.title)}
      </Typography>
      <ul>
        {group.items.map((item, index) =>
          item.subItems ? (
            <DashboardSidebarCollapsibleItem
              key={`${item.path}-${index}`}
              item={item}
            />
          ) : (
            <DashboardSidebarItem
              key={`${item.path}-${index}`}
              item={item}
              isActive={checkPathIsActive(item.path, pathname)}
            />
          )
        )}
      </ul>
    </div>
  )
}
