import { PopoverTrigger } from "@radix-ui/react-popover"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import { Popover, PopoverContent } from "@/components/ui/popover"

import DashboardSidebarCollapsibleContent from "../dashboard-sidebar-collapsible-content"
import { DashboardSidebarPopoverItemsProps } from "./dashboard-sidebar-popover-items.type"

export default function DashboardSidebarPopoverItems({
  open: openPopover,
  subItems,
  children,
  onOpenChange,
}: DashboardSidebarPopoverItemsProps) {
  const { open } = useDashboardSidebarStore()

  return (
    <Popover
      open={openPopover}
      onOpenChange={(value) => {
        if (open) return

        onOpenChange(value)
      }}
    >
      <PopoverTrigger className="w-full">{children}</PopoverTrigger>
      <PopoverContent className="w-auto" side="right" align="start">
        <DashboardSidebarCollapsibleContent
          subItems={subItems}
          hideSeparator
          onTogglePopover={() => onOpenChange(false)}
        />
      </PopoverContent>
    </Popover>
  )
}
