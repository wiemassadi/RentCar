import { SidebarItem } from "../dashboard-sidebar.type"

export type DashboardSidebarPopoverItemsProps = {
  open: boolean
  subItems: SidebarItem[]
  children: React.ReactNode
  onOpenChange: (open: boolean) => void
}
