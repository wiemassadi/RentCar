import { useTranslation } from "react-i18next"
import { useLocation, useNavigate } from "react-router-dom"

import { cn } from "@/lib/utils"

import { checkPathIsActive } from "@/helpers/path.helpers"

import { DashboardSidebarCollapsibleContentProps } from "./dashboard-sidebar-collapsible-content.type"

export default function DashboardSidebarCollapsibleContent({
  subItems,
  hideSeparator,
  onTogglePopover,
}: DashboardSidebarCollapsibleContentProps) {
  const { t } = useTranslation()

  const navigate = useNavigate()
  const { pathname } = useLocation()

  return (
    <ul className={cn("flex gap-x-4 pl-6", hideSeparator && "pl-0")}>
      {!hideSeparator && <div className="w-[1px] bg-gray-300" />}
      <div className="space-y-4">
        {subItems.map((subItem) => (
          <li
            key={subItem.path}
            className={cn(
              "group flex cursor-pointer items-center gap-x-2 text-sm text-app-gray-600 hover:text-app-gray-700",
              checkPathIsActive(subItem.path, pathname) &&
                "font-medium text-app-secondary-main hover:text-app-secondary-main"
            )}
            onClick={() => {
              navigate(subItem.path)
              onTogglePopover?.()
            }}
          >
            <subItem.icon
              className={cn(
                "size-6 text-app-gray-500 group-hover:text-app-gray-700",
                checkPathIsActive(subItem.path, pathname) &&
                  "text-app-secondary-main group-hover:text-app-secondary-main"
              )}
            />
            {t(subItem.label)}
          </li>
        ))}
      </div>
    </ul>
  )
}
