import { SidebarItem } from "../dashboard-sidebar.type"

export type DashboardSidebarCollapsibleContentProps = {
  subItems: SidebarItem[]
  hideSeparator?: boolean
  onTogglePopover?: () => void
}
