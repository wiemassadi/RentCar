import { useEffect, useState } from "react"

import { useLocation } from "react-router-dom"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import { checkPathIsActive } from "@/helpers/path.helpers"

import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible"

import DashboardSidebarCollapsibleContent from "../dashboard-sidebar-collapsible-content"
import DashboardSidebarItem from "../dashboard-sidebar-item"
import DashboardSidebarPopoverItems from "../dashboard-sidebar-popover-items"
import { DashboardSidebarCollapsibleItemProps } from "./dashboard-sidebar-collapsible-item.type"

export default function DashboardSidebarCollapsibleItem({
  item,
}: DashboardSidebarCollapsibleItemProps) {
  const { pathname } = useLocation()

  const [expanded, setExpanded] = useState(false)
  const [openPopover, setOpenPopover] = useState(false)

  const { open, openMobile } = useDashboardSidebarStore()

  const onExpand = () => {
    // Expand the item when the sidebar is open in mobile
    if (openMobile) {
      setExpanded((prev) => !prev)
    }

    // Expand the item when the sidebar is open in desktop
    if (!open) return

    setExpanded((prev) => !prev)
  }

  const onOpenPopover = (value: boolean) => {
    // Don't show the popover in the mobile sidebar
    if (openMobile) return

    setOpenPopover(value)
  }

  // Close the Expanded item when the sidebar is closed
  useEffect(() => {
    if (!open) {
      setExpanded(false)
    }
  }, [open])

  return (
    <Collapsible
      open={expanded}
      onOpenChange={setExpanded}
      onMouseLeave={() => setOpenPopover(false)}
    >
      <DashboardSidebarPopoverItems
        open={openPopover}
        subItems={item.subItems || []}
        onOpenChange={onOpenPopover}
      >
        <DashboardSidebarItem
          item={item}
          isActive={checkPathIsActive(item.path, pathname)}
          expanded={expanded}
          onExpand={onExpand}
          onOpenPopover={() => {
            if (openMobile) return

            setOpenPopover(true)
          }}
        />
      </DashboardSidebarPopoverItems>
      {item.subItems && (
        <CollapsibleContent>
          <DashboardSidebarCollapsibleContent subItems={item.subItems} />
        </CollapsibleContent>
      )}
    </Collapsible>
  )
}
