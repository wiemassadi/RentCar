import { SidebarItem } from "../dashboard-sidebar.type"

export type DashboardSidebarCollapsibleItemProps = {
  item: SidebarItem
}
