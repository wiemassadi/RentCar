import {
  Calendar,
  ChartColumn,
  Component,
  Database,
  Dot,
  House,
  LayoutDashboard,
  Mail,
  MessageCircle,
  Pin,
  UserCheck,
} from "lucide-react"

import { SidebarGroup } from "./dashboard-sidebar.type"

// TODO: Change this constant based on your needs
export const SIDEBAR_GROUPS: SidebarGroup[] = [
  {
    title: "sidebar.dashboard",
    items: [
      {
        label: "sidebar.home",
        icon: House,
        path: "/dashboard",
      },
      {
        label: "sidebar.data",
        icon: Database,
        path: "/dashboard/data",
      },
      {
        label: "sidebar.chart",
        icon: ChartColumn,
        path: "/dashboard/statistics",
      },
    ],
  },
  {
    title: "sidebar.application",
    items: [
      {
        label: "sidebar.users",
        icon: UserCheck,
        path: "/dashboard/users",
        subItems: [
          {
            label: "sidebar.all_users",
            path: "/dashboard",
            icon: Dot,
          },
          {
            label: "sidebar.active_users",
            path: "/dashboard/users/active",
            icon: Dot,
          },
          {
            label: "sidebar.inactive_users",
            path: "/dashboard/users/inactive",
            icon: Dot,
          },
        ],
      },
      {
        label: "sidebar.mail",
        icon: Mail,
        path: "/dashboard/mail",
      },
      {
        label: "sidebar.chat",
        icon: MessageCircle,
        path: "/dashboard/chat",
      },
      {
        label: "sidebar.calendar",
        icon: Calendar,
        path: "/dashboard/calendar",
      },
    ],
  },
  {
    title: "sidebar.forms",
    items: [
      {
        label: "sidebar.components",
        icon: Component,
        path: "/dashboard/forms/components",
      },
      {
        label: "sidebar.map",
        icon: Pin,
        path: "/dashboard/forms/map",
      },
      {
        label: "sidebar.layouts",
        icon: LayoutDashboard,
        path: "/dashboard/forms/layouts",
        subItems: [
          {
            label: "sidebar.layout_one",
            icon: Dot,
            path: "/dashboard/forms/layouts/layout1",
          },
          {
            label: "sidebar.layout_two",
            icon: Dot,
            path: "/dashboard/forms/layouts/layout2",
          },
          {
            label: "sidebar.layout_three",
            icon: Dot,
            path: "/dashboard/forms/layouts/layout3",
          },
        ],
      },
    ],
  },
]
