import { LucideIcon } from "lucide-react"

export type SidebarGroup = {
  title: string
  items: SidebarItem[]
}

export type SidebarItem = {
  label: string
  icon: LucideIcon
  path: string
  subItems?: SidebarItem[]
}
