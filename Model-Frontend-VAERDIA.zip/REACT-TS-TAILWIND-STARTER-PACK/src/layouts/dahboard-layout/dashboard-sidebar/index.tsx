import { cn } from "@/lib/utils"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import { SIDEBAR_GROUPS } from "./dashboard-sidebar-constants"
import DashboardSidebarGroup from "./dashboard-sidebar-group"

export default function DashboardSideBar() {
  const { open } = useDashboardSidebarStore()

  return (
    <div
      className={cn(
        "sticky top-[var(--top-bar-height)] hidden h-[calc(100vh-var(--top-bar-height))] w-[var(--sidebar-width)] space-y-2 divide-y overflow-auto overflow-x-hidden text-nowrap px-4 py-2 transition-all duration-300 ease-in md:block",
        !open && "w-[var(--sidebar-width-collapsed)] px-3"
      )}
    >
      {SIDEBAR_GROUPS.map((group, index) => (
        <DashboardSidebarGroup key={index} group={group} />
      ))}
    </div>
  )
}
