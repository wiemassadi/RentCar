import { BreakpointsEnum } from "@/config/enums/breakpoints.enum"

import useResponsive from "@/hooks/use-responsive"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTrigger,
} from "@/components/ui/sheet"

import TopBarLogo from "@/components/app-logos/top-bar-logo"

import { SIDEBAR_GROUPS } from "../dashboard-sidebar-constants"
import DashboardSidebarGroup from "../dashboard-sidebar-group"
import { DashboardSidebarSheetProps } from "./dashboard-sidebar-sheet.type"

export default function DashboardSidebarSheet({
  children,
}: DashboardSidebarSheetProps) {
  const { openMobile, toggleMobileSidebar } = useDashboardSidebarStore()

  const isTablet = useResponsive("down", BreakpointsEnum.Lg)

  // Open the Sheet when the screen is tablet
  const onToggleSheet = (value: boolean) => {
    if (isTablet) {
      toggleMobileSidebar(value)
      return
    }
  }

  return (
    <Sheet open={openMobile} onOpenChange={onToggleSheet}>
      <SheetTrigger asChild>{children}</SheetTrigger>
      <SheetContent side="left" className="overflow-y-auto p-0">
        <SheetHeader className="h-[var(--top-bar-height)]">
          <TopBarLogo fullWidth />
        </SheetHeader>
        <div className="px-4">
          {SIDEBAR_GROUPS.map((group, index) => (
            <DashboardSidebarGroup key={index} group={group} />
          ))}
        </div>
      </SheetContent>
    </Sheet>
  )
}
