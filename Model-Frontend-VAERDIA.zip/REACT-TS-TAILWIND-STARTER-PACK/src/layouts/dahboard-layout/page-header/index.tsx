import { useTranslation } from "react-i18next"

import { useAppGlobalStore } from "@/store/app-global-store"

import Typography from "@/components/typography"

import DashboardBreadCrumbs from "../dashboard-bread-crumbs"

export default function PageHeader() {
  const { t } = useTranslation()

  const {
    config: { pageTitle, breadCrumbs },
  } = useAppGlobalStore()

  return (
    <div className="flex flex-col items-start justify-between gap-y-2 lg:flex-row lg:items-center">
      <Typography variant="h1" bold>
        {t(pageTitle)}
      </Typography>
      <DashboardBreadCrumbs breadCrumbs={breadCrumbs} />
    </div>
  )
}
