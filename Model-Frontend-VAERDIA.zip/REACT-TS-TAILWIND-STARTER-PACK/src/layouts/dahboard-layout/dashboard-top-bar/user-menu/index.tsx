import { LogOut, User as UserIcon } from "lucide-react"
import { useTranslation } from "react-i18next"

import { User } from "@/types/models/user"

import { APP_CONFIG } from "@/config/constants/app.constants"
import { LocalStorageKeysEnum } from "@/config/enums/local-storage.enum"

import { getPersistedData } from "@/helpers/local-storage.helpers"

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

import ProfileAvatar from "@/components/profile-avatar"
import Typography from "@/components/typography"

export default function UserMenu() {
  const { t } = useTranslation()

  const user = getPersistedData<User>(LocalStorageKeysEnum.User, true)

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <div className="flex h-[var(--top-bar-height)] w-auto cursor-pointer items-center gap-x-4 px-2 hover:bg-app-primary-light/50">
          <ProfileAvatar
            src={user?.profilePicture || APP_CONFIG.EmptyString}
            alt={user?.name || APP_CONFIG.EmptyString}
            fallback="NP"
          />
          <Typography variant="h5" className="hidden text-white md:block">
            {user?.name || "Nom Prénom"}
          </Typography>
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-40">
        <DropdownMenuGroup>
          <DropdownMenuItem>
            <UserIcon />
            <Typography variant="h5" className="text-app-primary-dark">
              {t("common.profile")}
            </Typography>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem>
          <LogOut />
          <Typography variant="h5" className="text-app-primary-dark">
            {t("common.logout")}
          </Typography>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
