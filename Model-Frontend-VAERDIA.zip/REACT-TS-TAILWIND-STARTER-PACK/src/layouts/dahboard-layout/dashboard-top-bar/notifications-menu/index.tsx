import { DropdownMenuTrigger } from "@radix-ui/react-dropdown-menu"
import { BellRing } from "lucide-react"
import { useTranslation } from "react-i18next"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"

import NotificationMenuItem from "./notification-menu-item"

export default function NotificationsMenu() {
  const { t } = useTranslation()

  const notifications = [
    {
      label: "Votre mot de passe a été modifié avec succès.",
      date: "2024-12-10",
    },
    {
      label: "Nouvelle connexion détectée depuis un appareil inconnu.",
      date: "2024-12-09",
    },
    {
      label: "Votre demande de support a reçu une réponse.",
      date: "2024-12-08",
    },
    {
      label: "Mise à jour disponible pour votre application.",
      date: "2024-12-07",
    },
  ]

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="rounded-full">
          <BellRing className="animate-pulse text-app-secondary-main" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="mt-4 w-96">
        <DropdownMenuLabel className="flex items-center justify-between py-3 font-poppins text-app-primary-main">
          {t("dashboard.notifications")}
          <Badge className="rounded-2xl bg-app-secondary-main font-poppins hover:bg-app-secondary-main">
            {t("dashboard.new_notifications", { number: notifications.length })}
          </Badge>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup className="space-y-2">
          {notifications.map((notification, index) => (
            <NotificationMenuItem
              key={index}
              index={index}
              label={notification.label}
              date={notification.date}
            />
          ))}
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <Button
          className="w-full text-app-secondary-main hover:text-app-secondary-main"
          variant="ghost"
        >
          {t("dashboard.see_all_notifications")}
        </Button>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
