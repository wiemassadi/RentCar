import { Check, Trash } from "lucide-react"

import { cn } from "@/lib/utils"

import { DropdownMenuItem } from "@/components/ui/dropdown-menu"

import IconButton from "@/components/buttons/icon-button"
import Typography from "@/components/typography"

import { NotificationMenuItemProps } from "./notification-menu-item.type"

export default function NotificationMenuItem({
  index,
  label,
  date,
}: NotificationMenuItemProps) {
  return (
    <DropdownMenuItem
      className={cn(
        "flex cursor-auto items-start space-x-3 py-4 focus:bg-app-accent-blue-300",
        {
          "bg-app-accent-blue-100": index % 2 === 0,
        }
      )}
    >
      <div className="flex-1">
        <Typography variant="h5" className="text-app-primary-main">
          {label}
        </Typography>
        <Typography variant="h6" muted>
          {date}
        </Typography>
      </div>
      <div className="flex space-x-2">
        <IconButton
          title="common.mark_as_read"
          icon={Check}
          onClick={() => {}}
          iconClassName="text-green-500 hover:text-green-700"
        />
        <IconButton
          title="common.delete"
          icon={Trash}
          onClick={() => {}}
          iconClassName="text-red-500 hover:text-red-700"
        />
      </div>
    </DropdownMenuItem>
  )
}
