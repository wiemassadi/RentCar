export type NotificationMenuItemProps = {
  index: number
  label: string
  date: string
}
