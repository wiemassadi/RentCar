import { Menu } from "lucide-react"

import { BreakpointsEnum } from "@/config/enums/breakpoints.enum"

import useResponsive from "@/hooks/use-responsive"

import { useDashboardSidebarStore } from "@/store/dashboard-sidebar-store"

import TopBarLogo from "@/components/app-logos/top-bar-logo"
import IconButton from "@/components/buttons/icon-button"

import DashboardSidebarSheet from "../dashboard-sidebar/dashboard-sidebar-sheet"
import NotificationsMenu from "./notifications-menu"
import UserMenu from "./user-menu"

export default function DashboardTopBar() {
  const { open, toggleMobileSidebar, toggleSidebar } =
    useDashboardSidebarStore()

  const isTablet = useResponsive("down", BreakpointsEnum.Lg)

  const onToggleSidebar = () => {
    // Open the mobile sidebar when the screen is tablet
    if (isTablet) {
      toggleMobileSidebar(true)
      return
    }

    // Else, Open the desktop sidebar
    toggleSidebar(open ? false : true)
  }

  return (
    <div className="sticky top-0 z-10 flex h-[var(--top-bar-height)] items-center justify-between bg-app-primary-main text-white">
      <TopBarLogo />

      <div className="flex flex-grow items-center justify-end gap-x-2 lg:justify-between">
        <DashboardSidebarSheet>
          <IconButton
            title="common.toggle_sidebar"
            icon={Menu}
            onClick={onToggleSidebar}
          />
        </DashboardSidebarSheet>
        <div className="flex items-center gap-x-2">
          <NotificationsMenu />
          <UserMenu />
        </div>
      </div>
    </div>
  )
}
