import { BreadCrumbItem } from "@/types/interfaces/bread-crumb"

export type DashboardBreadCrumbsProps = {
  breadCrumbs: BreadCrumbItem[]
}
