import { House, Slash } from "lucide-react"
import { useTranslation } from "react-i18next"
import { useLocation, useNavigate } from "react-router-dom"

import { APP_CONFIG } from "@/config/constants/app.constants"
import { ROUTER_PATHS } from "@/config/constants/paths.constants"

import { cn } from "@/lib/utils"

import { checkPathIsActive } from "@/helpers/path.helpers"

import { DashboardBreadCrumbsProps } from "./dashboard-bread-crumbs.type"

export default function DashboardBreadCrumbs({
  breadCrumbs,
}: DashboardBreadCrumbsProps) {
  const { t } = useTranslation()
  const navigate = useNavigate()
  const { pathname } = useLocation()

  const navigateTo = (path?: string) => {
    if (path) navigate(path)
  }

  if (!breadCrumbs.length) return null

  return (
    <div className="flex items-center">
      <House
        className="size-5 cursor-pointer stroke-app-gray-400 hover:stroke-app-primary-main"
        onClick={() =>
          navigateTo(ROUTER_PATHS.DashboardPaths.DashboardRootPath)
        }
      />
      <Slash className="size-4 -rotate-12 text-app-gray-400" />
      {breadCrumbs.map((item, index) => (
        <div key={index} className="flex items-center">
          <span
            className={cn(
              "cursor-pointer font-poppins text-sm text-app-gray-400 hover:text-app-primary-main",
              {
                "cursor-auto hover:text-app-gray-400": !item.path,
                "font-semibold text-app-secondary-main hover:text-app-secondary-main":
                  checkPathIsActive(
                    item.path || APP_CONFIG.EmptyString,
                    pathname,
                    true
                  ),
              }
            )}
            onClick={() => navigateTo(item.path)}
          >
            {t(item.label)}
          </span>

          <Slash
            className={cn("block size-4 -rotate-12 text-app-gray-400", {
              hidden: index >= breadCrumbs.length - 1,
            })}
          />
        </div>
      ))}
    </div>
  )
}
