import { Suspense } from "react"

import { Outlet } from "react-router-dom"

import FallBackLoader from "@/components/loaders/fallback-loader"

import PageHeader from "../page-header"

export default function DashboardContent() {
  return (
    <main className="h-full space-y-3 bg-app-gray-100 p-4">
      <Suspense fallback={<FallBackLoader />}>
        <PageHeader />
        <Outlet />
      </Suspense>
    </main>
  )
}
