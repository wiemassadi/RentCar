import { create } from "zustand"

import { BreadCrumbItem } from "@/types/interfaces/bread-crumb"

import { APP_CONFIG } from "@/config/constants/app.constants"

type AppGlobalStore = {
  config: {
    pageTitle: string
    breadCrumbs: BreadCrumbItem[]
  }
  setConfig(config: { pageTitle: string; breadCrumbs: BreadCrumbItem[] }): void
  resetConfig: () => void
}

export const useAppGlobalStore = create<AppGlobalStore>((set) => ({
  config: {
    pageTitle: APP_CONFIG.EmptyString,
    breadCrumbs: [],
  },

  setConfig: (config) => set({ config }),

  resetConfig: () =>
    set({ config: { pageTitle: APP_CONFIG.EmptyString, breadCrumbs: [] } }),
}))
