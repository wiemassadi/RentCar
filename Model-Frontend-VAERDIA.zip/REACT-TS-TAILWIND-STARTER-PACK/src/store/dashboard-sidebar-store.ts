import { create } from "zustand"

type DashboardSidebarStore = {
  open: boolean
  openMobile: boolean
  isMobile: boolean
  setIsMobile: (value: boolean) => void
  toggleSidebar: (value: boolean) => void
  toggleMobileSidebar: (value: boolean) => void
}

export const useDashboardSidebarStore = create<DashboardSidebarStore>(
  (set) => ({
    open: true,
    isMobile: false,
    openMobile: false,
    toggleSidebar: (value) => {
      set(() => ({
        open: value,
      }))
    },
    setIsMobile: (value) => {
      set(() => ({
        isMobile: value,
      }))
    },
    toggleMobileSidebar: (value) => {
      set(() => ({
        openMobile: value,
      }))
    },
  })
)
