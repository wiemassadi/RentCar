import { useTranslation } from "react-i18next"

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "../ui/tooltip"
import { HintProps } from "./hint.type"

export default function Hint({
  title,
  children,
  align,
  alignOffset,
  side,
  sideOffset,
}: HintProps) {
  const { t } = useTranslation()

  if (!title) return <>{children}</>

  return (
    <TooltipProvider>
      <Tooltip delayDuration={100}>
        <TooltipTrigger asChild>{children}</TooltipTrigger>
        <TooltipContent
          className="bg-white text-gray-800 shadow"
          side={side}
          align={align}
          sideOffset={sideOffset}
          alignOffset={alignOffset}
        >
          <p className="font-poppins font-semibold capitalize">{t(title)}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
