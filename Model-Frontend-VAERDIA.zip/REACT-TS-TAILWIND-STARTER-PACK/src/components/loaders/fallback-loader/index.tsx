import { useTranslation } from "react-i18next"

import Typography from "@/components/typography"

export default function FallBackLoader() {
  const { t } = useTranslation()

  return (
    <div className="flex h-[90%] items-center justify-center space-x-2">
      <Typography variant="h4" bold>
        {t("common.loading")}
      </Typography>
      <span className="size-2 animate-bounce rounded-full bg-app-primary-main [animation-delay:-0.3s]" />
      <span className="size-2 animate-bounce rounded-full bg-app-primary-main [animation-delay:-0.15s]" />
      <span className="size-2 animate-bounce rounded-full bg-app-primary-main" />
    </div>
  )
}
