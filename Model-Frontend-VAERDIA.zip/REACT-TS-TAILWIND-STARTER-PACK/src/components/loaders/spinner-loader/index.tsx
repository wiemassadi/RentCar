import { Loader } from "lucide-react"

export default function SpinnerLoader() {
  return (
    <div className="flex items-center justify-center">
      <Loader className="size-5 animate-spin text-app-gray-400" />
    </div>
  )
}
