import { Helmet } from "react-helmet-async"
import { useTranslation } from "react-i18next"

import { CONFIG } from "@/config/config"

import { useAppGlobalStore } from "@/store/app-global-store"

export default function HelmetTitle() {
  const { t } = useTranslation()

  const {
    config: { pageTitle },
  } = useAppGlobalStore()

  return (
    <Helmet>
      <title>{pageTitle ? t(pageTitle) : CONFIG.APP_NAME}</title>
    </Helmet>
  )
}
