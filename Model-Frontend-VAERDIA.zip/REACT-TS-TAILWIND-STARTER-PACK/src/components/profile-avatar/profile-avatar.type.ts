export type ProfileAvatarProps = {
  src: string
  alt: string
  fallback: string
}
