import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar"
import { ProfileAvatarProps } from "./profile-avatar.type"

export default function ProfileAvatar({
  src,
  alt,
  fallback,
}: ProfileAvatarProps) {
  return (
    <Avatar>
      <AvatarImage src={src} alt={alt} />
      <AvatarFallback className="bg-app-primary-light">
        {fallback}
      </AvatarFallback>
    </Avatar>
  )
}
