import { InputConfig } from "@/types/interfaces/input-config"

export type TextInputProps = {
  config: InputConfig
  type: "text" | "number"
}
