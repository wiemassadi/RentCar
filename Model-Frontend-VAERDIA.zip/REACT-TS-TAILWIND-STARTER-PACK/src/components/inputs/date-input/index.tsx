import { useState } from "react"

import { format } from "date-fns"
import { enUS, fr } from "date-fns/locale"
import { CalendarIcon } from "lucide-react"
import { Matcher } from "react-day-picker"
import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import { APP_CONFIG } from "@/config/constants/app.constants"
import { LanguageShortLabelsEnum } from "@/config/enums/language.enum"

import { cn } from "@/lib/utils"

import useLanguage from "@/hooks/use-language"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

import InputLabel from "../input-label"
import { DateInputProps } from "./date-input.type"

export default function DateInput({
  config,
  fromYear,
  toYear,
  minDate,
  maxDate,
}: DateInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const { language } = useLanguage()

  const [isOpen, setIsOpen] = useState(false)

  const {
    name,
    label,
    placeholder,
    defaultValue,
    description,
    disabled,
    isRequired,
  } = config
  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem className="flex flex-col">
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <Popover open={isOpen} onOpenChange={setIsOpen}>
            <PopoverTrigger asChild>
              <FormControl>
                <Button
                  variant="outline"
                  disabled={disabled}
                  className={cn(
                    "pl-3 text-left font-normal",
                    !field.value && "text-muted-foreground"
                  )}
                >
                  {field.value ? (
                    format(
                      field.value,
                      APP_CONFIG.Date.Format.ReadableFullDate,
                      {
                        locale:
                          language === LanguageShortLabelsEnum.French
                            ? fr
                            : enUS,
                      }
                    )
                  ) : (
                    <span>{t(placeholder)}</span>
                  )}
                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                </Button>
              </FormControl>
            </PopoverTrigger>
            <PopoverContent className="w-full p-0" align="start">
              <Calendar
                mode="single"
                locale={language === LanguageShortLabelsEnum.French ? fr : enUS}
                captionLayout="dropdown"
                selected={field.value}
                onSelect={field.onChange}
                onDayClick={() => setIsOpen(false)}
                fromYear={fromYear}
                toYear={toYear}
                disabled={
                  [
                    minDate && { before: new Date(minDate) },
                    maxDate && { after: new Date(maxDate) },
                  ].filter(Boolean) as Matcher[]
                }
                defaultMonth={field.value}
              />
            </PopoverContent>
          </Popover>
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
