import { InputConfig } from "@/types/interfaces/input-config"

export type DateInputProps = {
  config: InputConfig
  fromYear?: number
  toYear?: number
  minDate?: Date | undefined
  maxDate?: Date | undefined
}
