import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

import InputLabel from "../input-label"
import { RadioGroupInputProps } from "./radio-group-input.type"

export default function RadioGroupInput({
  config,
  options,
  row,
}: RadioGroupInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const { name, label, description, defaultValue, disabled, isRequired } =
    config

  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem className="space-y-3">
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <FormControl>
            <RadioGroup
              onValueChange={field.onChange}
              defaultValue={field.value}
              disabled={disabled}
              className={cn(
                "flex flex-col space-y-1",
                row && "flex-row gap-x-4"
              )}
            >
              {options.map((option) => (
                <FormItem
                  key={option.value}
                  className="flex items-center space-x-3 space-y-0"
                >
                  <FormControl>
                    <RadioGroupItem
                      value={option.value}
                      checked={field.value === option.value}
                      className={cn(
                        "border-gray-400 text-primary",
                        field.value === option.value &&
                          "border-white ring-1 ring-primary ring-offset-2"
                      )}
                    />
                  </FormControl>
                  <FormLabel className="cursor-pointer font-normal">
                    {t(option.label)}
                  </FormLabel>
                </FormItem>
              ))}
            </RadioGroup>
          </FormControl>

          <FormMessage />
        </FormItem>
      )}
    />
  )
}
