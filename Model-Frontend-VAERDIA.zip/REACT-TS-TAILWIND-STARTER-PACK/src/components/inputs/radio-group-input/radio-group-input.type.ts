import { InputConfig, InputOption } from "@/types/interfaces/input-config"

export type RadioGroupInputProps = {
  config: InputConfig
  options: InputOption[]
  row?: boolean
}
