import { InputConfig } from "@/types/interfaces/input-config"

export type PhoneInputProps = {
  config: InputConfig
}
