import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form"
import { CustomPhoneInput } from "@/components/ui/phone-input"

import InputLabel from "../input-label"
import { PhoneInputProps } from "./phone-input.type"

export default function PhoneInput({ config }: PhoneInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const {
    name,
    label,
    placeholder,
    defaultValue,
    description,
    disabled,
    isRequired,
  } = config

  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem>
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <FormControl>
            <CustomPhoneInput
              name={field.name}
              value={field.value}
              placeholder={t(placeholder)}
              disabled={disabled}
              onChange={field.onChange}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
