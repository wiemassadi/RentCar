import { useState } from "react"

import { Eye, EyeClosed } from "lucide-react"
import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import { Button } from "@/components/ui/button"
import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"

import InputLabel from "../input-label"
import { PasswordInputProps } from "./password-input.type"

export default function PasswordInput({ config }: PasswordInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const [showPassword, setShowPassword] = useState(false)

  const {
    name,
    label,
    placeholder,
    description,
    defaultValue,
    disabled,
    isRequired,
  } = config

  const onToggle = () => setShowPassword((prev) => !prev)

  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem>
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <FormControl>
            <div className="relative">
              <Input
                name={field.name}
                type={showPassword ? "text" : "password"}
                placeholder={t(placeholder)}
                value={field.value}
                disabled={disabled}
                onChange={field.onChange}
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-[1px] top-0 rounded-l-none"
                onClick={onToggle}
              >
                {showPassword ? <EyeClosed /> : <Eye />}
              </Button>
            </div>
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
