import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"

import InputLabel from "../input-label"
import { EmailInputProps } from "./email-input.type"

export default function EmailInput({ config }: EmailInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const {
    name,
    label,
    description,
    placeholder,
    defaultValue,
    disabled,
    isRequired,
  } = config
  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem>
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <FormControl>
            <Input
              name={field.name}
              placeholder={t(placeholder)}
              value={field.value}
              disabled={disabled}
              onChange={field.onChange}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
