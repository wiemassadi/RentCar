import { InputConfig } from "@/types/interfaces/input-config"

export type EmailInputProps = {
  config: InputConfig
}
