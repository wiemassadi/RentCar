import { SearchIcon } from "lucide-react"
import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import { Input } from "@/components/ui/input"

import { SearchInputProps } from "./search-input.type"

export default function SearchInput({
  value,
  className,
  placeholder,
  onChange,
}: SearchInputProps) {
  const { t } = useTranslation()
  return (
    <div className={cn("relative min-w-full", className)}>
      <SearchIcon className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
      <Input
        className="pl-8"
        value={value}
        placeholder={t(placeholder)}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  )
}
