export type SearchInputProps = {
  value: string
  placeholder: string
  className?: string
  onChange: (value: string) => void
}
