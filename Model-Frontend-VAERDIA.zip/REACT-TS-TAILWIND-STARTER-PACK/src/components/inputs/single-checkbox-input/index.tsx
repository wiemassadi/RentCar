import { useFormContext } from "react-hook-form"

import { Checkbox } from "@/components/ui/checkbox"
import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form"

import InputLabel from "../input-label"
import { SingleCheckboxInputProps } from "./single-checkbox-input.type"

export default function SingleCheckboxInput({
  config,
}: SingleCheckboxInputProps) {
  const { control } = useFormContext()

  const { name, label, description, defaultValue, disabled, isRequired } =
    config

  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem
          className="flex cursor-pointer flex-row items-center gap-x-2 space-y-0"
          onClick={() => field.onChange(!field.value)}
        >
          <FormControl>
            <Checkbox
              className="border-gray-400 data-[state=checked]:border-none data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground data-[state=checked]:ring-1 data-[state=checked]:ring-primary data-[state=checked]:ring-offset-2"
              checked={field.value}
              onCheckedChange={field.onChange}
              disabled={disabled}
            />
          </FormControl>
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
