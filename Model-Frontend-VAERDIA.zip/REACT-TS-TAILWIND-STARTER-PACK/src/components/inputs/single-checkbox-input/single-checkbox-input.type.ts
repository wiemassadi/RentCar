import { InputConfig } from "@/types/interfaces/input-config"

export type SingleCheckboxInputProps = {
  config: InputConfig
}
