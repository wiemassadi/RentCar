import { InputConfig, InputOption } from "@/types/interfaces/input-config"

export type MultipleCheckBoxesInputProps = {
  config: InputConfig
  options: InputOption[]
}
