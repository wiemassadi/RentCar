import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import { Checkbox } from "@/components/ui/checkbox"
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"

import InputLabel from "../input-label"
import { MultipleCheckBoxesInputProps } from "./mutiple-check-boxes-input.type"

export default function MultipleCheckBoxesInput({
  config,
  options,
}: MultipleCheckBoxesInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const { name, label, description, defaultValue, disabled, isRequired } =
    config

  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={() => (
        <FormItem>
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          {options.map((option) => (
            <FormField
              key={option.value}
              control={control}
              name={name}
              defaultValue={defaultValue}
              render={({ field }) => {
                return (
                  <FormItem
                    key={option.value}
                    className="flex flex-row items-start space-x-3 space-y-0"
                  >
                    <FormControl>
                      <Checkbox
                        disabled={disabled}
                        checked={field.value?.includes(option.value)}
                        onCheckedChange={(checked) => {
                          return checked
                            ? field.onChange([...field.value, option.value])
                            : field.onChange(
                                field.value?.filter(
                                  (value: string) => value !== option.value
                                )
                              )
                        }}
                      />
                    </FormControl>
                    <FormLabel className="cursor-pointer font-normal">
                      {t(option.label)}
                    </FormLabel>
                  </FormItem>
                )
              }}
            />
          ))}
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
