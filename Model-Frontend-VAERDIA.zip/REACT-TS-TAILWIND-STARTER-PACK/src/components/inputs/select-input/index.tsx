import { useFormContext } from "react-hook-form"
import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import {
  FormControl,
  FormField,
  FormItem,
  FormMessage,
} from "@/components/ui/form"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"

import InputLabel from "../input-label"
import { SelectInputProps } from "./select-input.type"

export default function SelectInput({ config, options }: SelectInputProps) {
  const { control } = useFormContext()
  const { t } = useTranslation()

  const {
    name,
    label,
    placeholder,
    defaultValue,
    description,
    disabled,
    isRequired,
  } = config

  return (
    <FormField
      control={control}
      name={name}
      defaultValue={defaultValue}
      render={({ field }) => (
        <FormItem>
          <InputLabel
            label={label}
            description={description}
            isRequired={isRequired}
          />
          <Select
            onValueChange={field.onChange}
            defaultValue={field.value}
            disabled={disabled}
          >
            <FormControl>
              <SelectTrigger
                className={cn(!field.value && "text-muted-foreground")}
              >
                <SelectValue placeholder={t(placeholder)} />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {options.map((option, index) => (
                <div
                  key={`${option.value}-${index}`}
                  className="my-1 space-y-1"
                >
                  <SelectItem
                    value={option.value}
                    className="cursor-pointer font-poppins"
                  >
                    {t(option.label)}
                  </SelectItem>
                  {index < options.length - 1 && <Separator />}
                </div>
              ))}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  )
}
