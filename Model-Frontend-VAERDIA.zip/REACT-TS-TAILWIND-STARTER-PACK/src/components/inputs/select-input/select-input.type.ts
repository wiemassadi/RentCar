import { InputConfig, InputOption } from "@/types/interfaces/input-config"

export type SelectInputProps = {
  config: InputConfig
  options: InputOption[]
}
