import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import { FormDescription, FormLabel } from "@/components/ui/form"

import { InputLabelProps } from "./input-label.type"

export default function InputLabel({
  label,
  description,
  isRequired,
}: InputLabelProps) {
  const { t } = useTranslation()
  return (
    <div className="-space-y-1">
      <FormLabel
        className={cn(
          isRequired && "after:ml-0.5 after:text-red-500 after:content-['*']"
        )}
      >
        {t(label)}
      </FormLabel>
      {description && <FormDescription>{t(description)}</FormDescription>}
    </div>
  )
}
