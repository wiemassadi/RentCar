export type InputLabelProps = {
  label: string
  description?: string
  isRequired?: boolean
}
