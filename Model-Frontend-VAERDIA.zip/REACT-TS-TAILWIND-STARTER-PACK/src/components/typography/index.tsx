import { cn } from "@/lib/utils"

import { TypographyProps } from "./typography.type"

export default function Typography({
  variant,
  children,
  bold,
  overflow,
  muted,
  className,
}: TypographyProps) {
  const Component = variant

  return (
    <Component
      className={cn(
        "font-poppins text-app-primary-main/90",
        {
          "font-semibold": bold,
          "text-[22px]": variant === "h1",
          "text-[20px]": variant === "h2",
          "text-[18px]": variant === "h3",
          "text-[16px]": variant === "h4",
          "text-[14px]": variant === "h5",
          "text-[12px]": variant === "h6",
          truncate: overflow,
          "text-app-gray-400": muted,
        },
        className
      )}
    >
      {children}
    </Component>
  )
}
