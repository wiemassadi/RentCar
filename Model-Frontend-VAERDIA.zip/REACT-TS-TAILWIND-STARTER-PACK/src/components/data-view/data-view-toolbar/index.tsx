import { CloudDownload, Filter, Plus } from "lucide-react"

import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"

import HoverActionButton from "@/components/buttons/hover-action-button"
import IconButton from "@/components/buttons/icon-button"
import SearchInput from "@/components/inputs/search-input"

import { DataViewToolbarProps } from "./data-view-toolbar.type"

export default function DataViewToolbar({
  searchText,
  searchTextPlaceholder,
  onSearchTextChange,
  renderFilters,
  onAddClick,
  onDownloadClick,
}: DataViewToolbarProps) {
  return (
    <div className="flex flex-col items-center justify-between gap-y-3 md:flex-row">
      <div className="flex w-full items-center gap-x-2 md:w-[50%]">
        <SearchInput
          value={searchText}
          placeholder={searchTextPlaceholder}
          onChange={onSearchTextChange}
        />

        {onDownloadClick && (
          <IconButton
            title="common.download"
            icon={CloudDownload}
            onClick={onDownloadClick}
            iconClassName="hidden flex-shrink-0 text-app-secondary-main hover:text-app-secondary-main md:flex"
          />
        )}
      </div>

      <div className="flex w-full flex-col justify-end gap-x-3 gap-y-2 md:w-[40%] md:flex-row">
        {onDownloadClick && (
          <HoverActionButton
            className="flex bg-app-primary-main/80 text-white hover:bg-app-primary-main hover:text-white md:hidden"
            label="common.download"
            icon={CloudDownload}
            iconPlacement="right"
            onClick={onDownloadClick}
          />
        )}

        {renderFilters && (
          <Popover>
            <PopoverTrigger>
              <HoverActionButton
                label="common.filter"
                className="w-full"
                icon={Filter}
                iconPlacement="right"
              />
            </PopoverTrigger>
            <PopoverContent>{renderFilters()}</PopoverContent>
          </Popover>
        )}

        {onAddClick && (
          <HoverActionButton
            label="common.add"
            icon={Plus}
            iconPlacement="right"
            onClick={onAddClick}
          />
        )}
      </div>
    </div>
  )
}
