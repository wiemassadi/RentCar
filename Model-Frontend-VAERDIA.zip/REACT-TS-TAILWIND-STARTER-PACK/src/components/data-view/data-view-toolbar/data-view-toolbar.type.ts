export type DataViewToolbarProps = {
  searchText: string
  searchTextPlaceholder: string
  onSearchTextChange: (value: string) => void
  renderFilters?: () => React.ReactNode
  onAddClick?: () => void
  onDownloadClick?: () => void
}
