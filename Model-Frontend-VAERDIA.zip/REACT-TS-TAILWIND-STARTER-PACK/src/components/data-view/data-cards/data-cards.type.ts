export type DataCardsProps<T> = {
  data: T[] | undefined
  isFetching: boolean
  errorMessage?: string
  renderCard: (item: T) => React.ReactNode
}
