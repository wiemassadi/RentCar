import React from "react"

import ErrorMessage from "@/components/error-message"
import SpinnerLoader from "@/components/loaders/spinner-loader"

import { DataCardsProps } from "./data-cards.type"

export default function DataCards<T>({
  data,
  isFetching,
  errorMessage,
  renderCard,
}: DataCardsProps<T>) {
  if (isFetching) return <SpinnerLoader />

  if (errorMessage) return <ErrorMessage message={errorMessage} />

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 2xl:2xl:grid-cols-4">
      {data &&
        data.map((item, index) => (
          <React.Fragment key={index}>{renderCard(item)}</React.Fragment>
        ))}
    </div>
  )
}
