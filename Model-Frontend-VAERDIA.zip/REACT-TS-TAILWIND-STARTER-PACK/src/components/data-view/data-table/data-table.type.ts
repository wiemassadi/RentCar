import { RowData, Table } from "@tanstack/react-table"

export type DataTableProps<T extends RowData> = {
  table: Table<T>
  isFetching: boolean
  errorMessage?: string
}
