import { Table } from "@tanstack/react-table"

import { PaginatorMethods } from "@/types/interfaces/paginator"

export type DataViewProps<T> = {
  data: T[] | undefined
  table: Table<T>
  isFetching: boolean
  paginatorMethods: PaginatorMethods
  searchTextPlaceholder: string
  totalPages: number | undefined
  errorMessage?: string
  WithCardView?: boolean
  renderCard: (item: T) => React.ReactNode
  renderFilters?: () => React.ReactNode
  onAddClick?: () => void
  onDownloadClick?: () => void
}
