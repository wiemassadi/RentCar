import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent } from "@/components/ui/tabs"

import DataCards from "./data-cards"
import DataTable from "./data-table"
import DataViewPagination from "./data-view-pagination"
import DataViewTabs from "./data-view-tabs"
import DataViewToolbar from "./data-view-toolbar"
import { DataViewProps } from "./data-view.type"

export default function DataView<T>({
  data,
  table,
  isFetching,
  paginatorMethods,
  searchTextPlaceholder,
  totalPages,
  errorMessage,
  WithCardView = true,
  renderCard,
  renderFilters,
  onAddClick,
  onDownloadClick,
}: DataViewProps<T>) {
  const { paginator, changeSearchText, changePage, changeRowsPerPage } =
    paginatorMethods

  const { search, rowsPerPage, page } = paginator

  return (
    <Tabs defaultValue="table" className="flex flex-col">
      {WithCardView && <DataViewTabs />}
      <Card className="flex flex-col gap-y-4 rounded-lg rounded-tr-none p-4 shadow-none">
        <DataViewToolbar
          searchText={search}
          searchTextPlaceholder={searchTextPlaceholder}
          onSearchTextChange={changeSearchText}
          renderFilters={renderFilters}
          onAddClick={onAddClick}
          onDownloadClick={onDownloadClick}
        />

        <Separator />

        <TabsContent value="table">
          <DataTable
            isFetching={isFetching}
            table={table}
            errorMessage={errorMessage}
          />
        </TabsContent>

        <TabsContent value="card">
          <DataCards
            data={data}
            isFetching={isFetching}
            renderCard={renderCard}
            errorMessage={errorMessage}
          />
        </TabsContent>

        <Separator />

        <DataViewPagination
          currentPage={page}
          rowsPerPage={rowsPerPage}
          totalPages={totalPages}
          changePage={changePage}
          changeRowsPerPage={changeRowsPerPage}
        />
      </Card>
    </Tabs>
  )
}
