import { LayoutGrid, Table2 } from "lucide-react"

import { TabsList, TabsTrigger } from "@/components/ui/tabs"

import Hint from "@/components/hint"

export default function DataViewTabs() {
  return (
    <TabsList className="ml-auto space-x-2 rounded-b-none bg-app-primary-main">
      <TabsTrigger
        value="table"
        className="rounded-sm hover:bg-app-primary-light/50 data-[state=active]:bg-app-secondary-main data-[state=active]:text-white"
      >
        <Hint title="common.table_view">
          <Table2 className="size-5" />
        </Hint>
      </TabsTrigger>
      <TabsTrigger
        value="card"
        className="rounded-sm hover:bg-app-primary-light/50 data-[state=active]:bg-app-secondary-main data-[state=active]:text-white"
      >
        <Hint title="common.card_view">
          <LayoutGrid className="size-5" />
        </Hint>
      </TabsTrigger>
    </TabsList>
  )
}
