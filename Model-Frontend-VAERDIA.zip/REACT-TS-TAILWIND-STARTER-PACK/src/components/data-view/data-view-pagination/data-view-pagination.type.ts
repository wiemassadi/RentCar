export type DataViewPaginationProps = {
  currentPage: number
  rowsPerPage: number
  totalPages: number | undefined
  changePage: (page: number) => void
  changeRowsPerPage: (rowsPerPage: number) => void
}
