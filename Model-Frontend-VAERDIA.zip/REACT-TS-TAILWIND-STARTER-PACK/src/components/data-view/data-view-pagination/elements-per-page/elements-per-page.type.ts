export type ElementsPerPageProps = {
  rowsPerPage: number
  changeRowsPerPage: (rowsPerPage: number) => void
}
