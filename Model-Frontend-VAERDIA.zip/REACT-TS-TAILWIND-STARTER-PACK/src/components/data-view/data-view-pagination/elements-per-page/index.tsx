import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"

import Typography from "@/components/typography"

import { ELEMENTS_PER_PAGE_OPTIONS } from "./elements-per-page.constants"
import { ElementsPerPageProps } from "./elements-per-page.type"

export default function ElementsPerPage({
  rowsPerPage,
  changeRowsPerPage,
}: ElementsPerPageProps) {
  const { t } = useTranslation()
  return (
    <div className="flex items-center gap-x-1">
      {ELEMENTS_PER_PAGE_OPTIONS.map((option) => (
        <Button
          key={option}
          className={cn("text-app-primary-main hover:text-app-primary-main", {
            "border border-app-primary-light bg-accent": rowsPerPage === option,
          })}
          variant="ghost"
          size="icon"
          onClick={() => changeRowsPerPage(option)}
        >
          {option}
        </Button>
      ))}

      <Typography variant="h5" muted>
        {t("common.elements_per_page")}
      </Typography>
    </div>
  )
}
