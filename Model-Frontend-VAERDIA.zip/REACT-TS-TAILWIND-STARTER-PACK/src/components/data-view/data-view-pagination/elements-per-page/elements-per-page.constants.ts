import { APP_CONFIG } from "@/config/constants/app.constants"

export const ELEMENTS_PER_PAGE_OPTIONS = [
  APP_CONFIG.Pagination.ElementsPerPage.Min,
  APP_CONFIG.Pagination.ElementsPerPage.Medium,
  APP_CONFIG.Pagination.ElementsPerPage.Max,
]
