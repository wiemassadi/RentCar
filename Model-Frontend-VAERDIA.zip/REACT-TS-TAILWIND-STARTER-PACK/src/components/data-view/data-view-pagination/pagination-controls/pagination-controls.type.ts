export type PaginationControlsProps = {
  currentPage: number
  totalPages: number | undefined
  changePage: (page: number) => void
}
