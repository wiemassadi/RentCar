import { useEffect, useState } from "react"

import { ChevronLeft, ChevronRight } from "lucide-react"

import { APP_CONFIG } from "@/config/constants/app.constants"

import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
} from "@/components/ui/pagination"

import { PaginationControlsProps } from "./pagination-controls.type"

export default function PaginationControls({
  currentPage,
  totalPages,
  changePage,
}: PaginationControlsProps) {
  const [numberOfPages, setNumberOfPages] = useState(1)

  useEffect(() => {
    if (totalPages) {
      setNumberOfPages(totalPages)
    }
  }, [totalPages])

  // Helper to generate pages with ellipsis
  const generatePagination = () => {
    const pages = []
    const showLeftEllipsis = currentPage > 3
    const showRightEllipsis = currentPage < numberOfPages - 2

    // First page
    pages.push(1)

    if (showLeftEllipsis) {
      pages.push("left-ellipsis")
    }

    // Pages around the current page
    const startPage = Math.max(2, currentPage - 1)
    const endPage = Math.min(numberOfPages - 1, currentPage + 1)
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i)
    }

    if (showRightEllipsis) {
      pages.push("right-ellipsis")
    }

    // Last page
    pages.push(totalPages)

    return pages
  }

  const pages = generatePagination()

  return (
    <div>
      <Pagination>
        <PaginationContent>
          <Button
            className="text-app-primary-main"
            variant="ghost"
            size="icon"
            disabled={currentPage === APP_CONFIG.Pagination.FirstPage}
            onClick={() => changePage(currentPage - 1)}
          >
            <ChevronLeft />
          </Button>

          {pages.map((page, index) => (
            <PaginationItem key={index} className="text-app-primary-main">
              {page === "left-ellipsis" || page === "right-ellipsis" ? (
                <PaginationEllipsis className="cursor-auto" />
              ) : (
                <PaginationLink
                  isActive={currentPage === page}
                  className={cn({
                    "border border-app-primary-light bg-accent":
                      currentPage === page,
                  })}
                  onClick={() => changePage(page as number)}
                >
                  {page}
                </PaginationLink>
              )}
            </PaginationItem>
          ))}

          <Button
            className="text-app-primary-main"
            variant="ghost"
            size="icon"
            disabled={currentPage === totalPages}
            onClick={() => changePage(currentPage + 1)}
          >
            <ChevronRight />
          </Button>
        </PaginationContent>
      </Pagination>
    </div>
  )
}
