import { DataViewPaginationProps } from "./data-view-pagination.type"
import ElementsPerPage from "./elements-per-page"
import PaginationControls from "./pagination-controls"

export default function DataViewPagination({
  currentPage,
  rowsPerPage,
  totalPages,
  changePage,
  changeRowsPerPage,
}: DataViewPaginationProps) {
  return (
    <div className="flex flex-col items-center justify-between gap-y-2 md:flex-row">
      <ElementsPerPage
        rowsPerPage={rowsPerPage}
        changeRowsPerPage={changeRowsPerPage}
      />
      <PaginationControls
        currentPage={currentPage}
        totalPages={totalPages}
        changePage={changePage}
      />
    </div>
  )
}
