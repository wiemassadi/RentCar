export type ErrorMessageProps = {
  message: string
}
