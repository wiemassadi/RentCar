import { TriangleAlert } from "lucide-react"
import { useTranslation } from "react-i18next"

import Typography from "../typography"
import { ErrorMessageProps } from "./error-message.type"

export default function ErrorMessage({ message }: ErrorMessageProps) {
  const { t } = useTranslation()

  return (
    <div className="flex items-center justify-center gap-x-2">
      <TriangleAlert className="size-5 text-app-gray-400" />
      <Typography variant="h5" muted>
        {t(message)}
      </Typography>
    </div>
  )
}
