export type TopBarLogoProps = {
  fullWidth?: boolean
}
