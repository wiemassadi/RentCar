import { useTranslation } from "react-i18next"
import { useNavigate } from "react-router-dom"

import { ROUTER_PATHS } from "@/config/constants/paths.constants"

import { cn } from "@/lib/utils"

import { TopBarLogoProps } from "./top-bar-logo.type"

export default function TopBarLogo({ fullWidth }: TopBarLogoProps) {
  const { t } = useTranslation()
  const navigate = useNavigate()

  return (
    <div
      className={cn(
        "flex h-[var(--top-bar-height)] w-[var(--sidebar-width)] items-center justify-start bg-app-primary-main",
        {
          "w-full": fullWidth,
        }
      )}
    >
      <img
        src="/images/app-logo.png"
        alt={t("alt.top_bar_logo")}
        className="h-[30px] cursor-pointer object-fill"
        onClick={() => navigate(ROUTER_PATHS.DashboardPaths.DashboardRootPath)}
      />
    </div>
  )
}
