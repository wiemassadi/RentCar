import { LucideIcon } from "lucide-react"

export type IconButtonProps = {
  title: string
  icon: LucideIcon
  iconClassName?: string
  onClick: () => void
}
