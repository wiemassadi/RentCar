import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"

import Hint from "@/components/hint"

import { IconButtonProps } from "./icon-button.type"

export default function IconButton({
  title,
  icon: Icon,
  iconClassName,
  onClick,
}: IconButtonProps) {
  return (
    <Hint title={title}>
      <Button
        className={cn("rounded-full", iconClassName)}
        variant="ghost"
        size="icon"
        onClick={onClick}
      >
        <Icon />
      </Button>
    </Hint>
  )
}
