export type LoadingButtonProps = {
  label: string
  isLoading: boolean
  className?: string
  onClick: () => void
}
