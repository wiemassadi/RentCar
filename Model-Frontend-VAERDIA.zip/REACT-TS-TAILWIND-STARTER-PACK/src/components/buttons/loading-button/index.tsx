import { Loader } from "lucide-react"
import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"

import { LoadingButtonProps } from "./loading-button.type"

export default function LoadingButton({
  label,
  isLoading,
  className,
  onClick,
}: LoadingButtonProps) {
  const { t } = useTranslation()
  return (
    <Button
      className={cn("w-full", className)}
      variant="ringHover"
      disabled={isLoading}
      onClick={onClick}
    >
      {isLoading ? <Loader className="animate-spin" /> : t(label)}
    </Button>
  )
}
