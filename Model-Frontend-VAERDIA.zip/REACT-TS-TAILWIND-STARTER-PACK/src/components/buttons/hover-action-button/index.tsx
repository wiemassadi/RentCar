import { useTranslation } from "react-i18next"

import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"

import { HoverActionButtonProps } from "./hover-action-button.type"

export default function HoverActionButton({
  label,
  icon: Icon,
  className,
  iconPlacement = "left",
  onClick,
}: HoverActionButtonProps) {
  const { t } = useTranslation()
  return (
    <Button
      className={cn(
        "bg-app-secondary-light text-app-secondary-main hover:bg-app-secondary-main hover:text-white",
        className
      )}
      variant="expandIcon"
      Icon={Icon}
      iconPlacement={iconPlacement}
      onClick={onClick}
    >
      {t(label)}
    </Button>
  )
}
