import { LucideIcon } from "lucide-react"

export type HoverActionButtonProps = {
  label: string
  icon: LucideIcon
  iconPlacement?: "left" | "right"
  className?: string
  onClick?: () => void
}
