import { alt } from "./alt"
import { auth } from "./auth"
import { common } from "./common"
import { dashboard } from "./dashboard"
import { sidebar } from "./sidebar"

const fr = {
  common,
  auth,
  sidebar,
  alt,
  dashboard,
}

export default fr
