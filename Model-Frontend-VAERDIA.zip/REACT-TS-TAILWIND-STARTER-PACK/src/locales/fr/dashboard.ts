export const dashboard = {
  dashboard_page_title: "Tableau de bord",
  notifications: "Notifications",
  see_all_notifications: "Voir toutes les notifications",
  new_notifications: "{{number}} Nouveaux",
}
