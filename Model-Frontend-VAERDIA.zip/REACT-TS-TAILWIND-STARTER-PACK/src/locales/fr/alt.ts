export const alt = {
  top_bar_logo: "Logo de l'application",
}
