import i18n from "i18next"
import { initReactI18next } from "react-i18next"

import { LanguageShortLabelsEnum } from "@/config/enums/language.enum"

import en from "./en"
import fr from "./fr"

const i18nInstance = i18n.createInstance()

i18nInstance.use(initReactI18next).init({
  resources: {
    en: {
      translation: en,
    },
    fr: {
      translation: fr,
    },
  },
  lng: LanguageShortLabelsEnum.French,
  fallbackLng: LanguageShortLabelsEnum.French,
  interpolation: {
    escapeValue: false,
  },
})

export default i18nInstance
