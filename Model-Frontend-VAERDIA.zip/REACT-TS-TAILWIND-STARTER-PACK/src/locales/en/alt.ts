export const alt = {
  top_bar_logo: "Application logo",
}
