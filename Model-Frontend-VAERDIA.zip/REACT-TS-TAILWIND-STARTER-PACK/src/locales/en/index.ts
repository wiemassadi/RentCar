import { alt } from "./alt"
import { auth } from "./auth"
import { common } from "./common"
import { dashboard } from "./dashboard"
import { sidebar } from "./sidebar"

const en = {
  common,
  auth,
  sidebar,
  alt,
  dashboard,
}

export default en
