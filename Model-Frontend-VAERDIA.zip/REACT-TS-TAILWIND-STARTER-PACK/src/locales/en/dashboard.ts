export const dashboard = {
  dashboard_page_title: "Dashboard",
  notifications: "Notifications",
  see_all_notifications: "See all notifications",
}
