export const auth = {
  login: "Login",
  logout: "Logout",
  register: "Register",
  email: "Email",
  email_placeholder: "Enter your email",
  password: "Password",
  password_placeholder: "Enter your password",
  login_success: "Login successful",
  login_error: "Login error",

  formValidation: {
    email_required: "Email is required",
    email_too_long: "Email is too long",
    email_invalid: "Email is invalid",
    password_too_short: "Password is too short",
    password_too_long: "Password is too long",
    password_required: "Password is required",
  },
}
