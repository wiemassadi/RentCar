export const common = {
  delete: "Delete",
  edit: "Edit",
  save: "Save",
  cancel: "Cancel",
  add: "Add",
  back: "Back",
  search_for_country: "Search for country...",
  no_country_found: "No country found",
}
