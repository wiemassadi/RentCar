import { useState } from "react"

import { Paginator, PaginatorMethods } from "@/types/interfaces/paginator"

import { APP_CONFIG } from "@/config/constants/app.constants"

const INITIAL_PAGINATOR: Paginator = {
  page: 1,
  rowsPerPage: APP_CONFIG.Pagination.ElementsPerPage.Min,
  paginated: true,
  search: "",
  orderType: "desc",
  orderBy: "",
}

export default function usePagination(
  initialPaginator?: Paginator
): PaginatorMethods {
  const [paginator, setPaginator] = useState<Paginator>(
    initialPaginator ?? INITIAL_PAGINATOR
  )

  const changePage = (newPage: number) => {
    setPaginator((prev) => ({ ...prev, page: newPage }))
  }

  const changeOrderBy = (newOrderBy: string) => {
    const isDesc =
      paginator.orderBy === newOrderBy && paginator.orderType === "desc"
    setPaginator((prev) => ({
      ...prev,
      page: 1,
      orderBy: newOrderBy,
      orderType: isDesc ? "asc" : "desc",
    }))
  }

  const changeSearchText = (newSearchText: string) => {
    setPaginator((prev) => ({ ...prev, page: 1, search: newSearchText }))
  }

  const changeRowsPerPage = (newRowsPerPage: number) => {
    setPaginator((prev) => ({ ...prev, page: 1, rowsPerPage: newRowsPerPage }))
  }

  const resetPaginator = () => {
    setPaginator(initialPaginator ?? INITIAL_PAGINATOR)
  }

  return {
    paginator,
    changePage,
    changeOrderBy,
    changeSearchText,
    changeRowsPerPage,
    resetPaginator,
  }
}
