import { useEffect, useState } from "react"

import i18nInstance from "@/locales/i18n"

import { LanguageShortLabelsEnum } from "@/config/enums/language.enum"

export default function useLanguage() {
  const [language, setLanguage] = useState<string>(
    i18nInstance.language ?? LanguageShortLabelsEnum.French
  )

  useEffect(() => {
    setLanguage(i18nInstance.language)
  }, [i18nInstance.language])

  const handleChangeLanguage = (lng: string) => {
    i18nInstance.changeLanguage(lng)
  }

  return { language, handleChangeLanguage }
}
