import { useMemo } from "react"

import {
  ColumnDef,
  getCoreRowModel,
  useReactTable,
} from "@tanstack/react-table"

import { PaginationResponse } from "@/types/models/pagination"

import { APP_CONFIG } from "@/config/constants/app.constants"

type UseTableProps<T> = {
  paginationResponse?: PaginationResponse<T>
  columns: ColumnDef<T>[]
  rowsPerPage: number
}

export default function useTable<T>({
  columns,
  paginationResponse,
  rowsPerPage,
}: UseTableProps<T>) {
  const fallBackData = useMemo<T[]>(() => [], [])

  const table = useReactTable({
    data: paginationResponse?.data || fallBackData,
    columns,
    manualPagination: true,
    rowCount: rowsPerPage,
    pageCount: paginationResponse?.lastPage,
    state: {
      pagination: {
        pageIndex:
          paginationResponse?.currentPage || APP_CONFIG.Pagination.FirstPage,
        pageSize: rowsPerPage,
      },
    },
    getCoreRowModel: getCoreRowModel(),
  })

  return table
}
