import { useEffect, useState } from "react"

export default function useResponsive(
  query: "up" | "down" | "between" | "only",
  key: number,
  start?: number,
  end?: number
) {
  const [matches, setMatches] = useState(false)

  useEffect(() => {
    let mediaQuery

    // Define the media query based on the input parameters
    if (query === "up") {
      mediaQuery = `(min-width: ${key}px)`
    } else if (query === "down") {
      mediaQuery = `(max-width: ${key}px)`
    } else if (query === "between" && start != null && end != null) {
      mediaQuery = `(min-width: ${start}px) and (max-width: ${end}px)`
    } else if (query === "only") {
      mediaQuery = `(min-width: ${key}px) and (max-width: ${key}px)`
    }

    if (mediaQuery) {
      const mediaQueryList = window.matchMedia(mediaQuery)

      const updateMatches = () => setMatches(mediaQueryList.matches)
      updateMatches()

      mediaQueryList.addEventListener("change", updateMatches)

      return () => mediaQueryList.removeEventListener("change", updateMatches)
    }
  }, [query, key, start, end])

  return matches
}
