import { QueryClient } from "@tanstack/react-query"

import { APP_CONFIG } from "@/config/constants/app.constants"

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: APP_CONFIG.QueryClient.Retry,
      retryDelay: APP_CONFIG.QueryClient.RetryDelay,
      refetchOnWindowFocus: APP_CONFIG.QueryClient.RefetchOnWindowFocus,
      staleTime: APP_CONFIG.QueryClient.StaleTime,
    },
  },
})
