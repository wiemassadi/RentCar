import axios from "axios"

import { CONFIG } from "@/config/config"
import { ROUTER_PATHS } from "@/config/constants/paths.constants"

import {
  clearLocalStorage,
  getPersistedData,
} from "@/helpers/local-storage.helpers"

const axiosClient = axios.create({
  baseURL: CONFIG.ENDPOINT_BASE_URL,
  headers: {
    Accept: "application/json",
    "Content-Type": "application/json",
  },
})

axiosClient.interceptors.request.use(
  (config) => {
    if (!config.headers) return config

    const token = getPersistedData<string>("token")

    if (token) {
      config.headers["Authorization"] = `Bearer ${token}`
    }

    return config
  },
  (error) => Promise.reject(error)
)

axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      if (window.location.pathname !== ROUTER_PATHS.AuthPaths.LoginPath) {
        clearLocalStorage()
        window.location.href = ROUTER_PATHS.AuthPaths.LoginPath
      }
    }

    return Promise.reject(error)
  }
)

export default axiosClient
