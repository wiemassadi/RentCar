import { useErrorBoundary, withErrorBoundary } from "react-use-error-boundary"

import { Toaster } from "@/components/ui/toaster"

import HelmetTitle from "@/components/helmet-title"

import Router from "./routes/router"

function App() {
  const [error, resetError] = useErrorBoundary()

  return (
    <>
      <HelmetTitle />
      <Toaster />
      {error ? (
        <div className="text-5xl text-white" onClick={resetError}>
          Error
        </div>
      ) : (
        <Router />
      )}
    </>
  )
}

const AppWithErrorBoundary = withErrorBoundary(App)

export default AppWithErrorBoundary
