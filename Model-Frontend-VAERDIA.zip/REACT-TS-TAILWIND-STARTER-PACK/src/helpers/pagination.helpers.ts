import { Paginator } from "@/types/interfaces/paginator"
import { PaginationApiResponse } from "@/types/models/pagination"

import { toSnakeCase } from "./string.helpers"

export const transformPaginationResponse = <T>(
  response: PaginationApiResponse<T>
) => {
  return {
    currentPage: response.current_page,
    lastPage: response.last_page,
    perPage: response.per_page,
    total: response.total,
  }
}

export const transformPaginationIntoQueryParams = (
  url: string,
  paginator: Paginator
): string => {
  let result = `${url}?`

  Object.entries(paginator).forEach(([key, value]) => {
    if (value) {
      const snakeKey = toSnakeCase(key)
      result += `${snakeKey}=${value}&`
    }
  })

  if (result.endsWith("&")) {
    result = result.slice(0, -1)
  }

  return result
}
