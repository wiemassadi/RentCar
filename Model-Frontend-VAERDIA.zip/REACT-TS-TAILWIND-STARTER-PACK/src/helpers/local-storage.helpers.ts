import CryptoJS from "crypto-js"
import { isString } from "lodash"

import { CONFIG } from "@/config/config"

/**
 * Save data in the local storage by a key
 * @param key string
 * @param data unknown
 */
export const persistData = (key: string, data: unknown) => {
  // Check if the data is a string or an object
  const dataString: string = isString(data)
    ? (data as string)
    : JSON.stringify(data)

  // Encrypt the data before storing it in the local storage
  const encrypted = CryptoJS.AES.encrypt(
    dataString,
    CONFIG.LOCAL_STORAGE_SECRET_KEY
  ).toString()

  // Set the encrypted data in the local storage
  localStorage.setItem(key, encrypted)
}

/**
 * Extract data from local storage buy a key
 * Use parse to return the data as an object
 * @param key string
 * @param parse boolean
 * @returns string | object
 */
export const getPersistedData = <T>(key: string, parse?: boolean): T | null => {
  // Get the encrypted data from the local storage
  const encryptedString = localStorage.getItem(key) ?? ""

  if (encryptedString) {
    // Decrypt the data before returning it
    const decryptedString = CryptoJS.AES.decrypt(
      encryptedString,
      CONFIG.LOCAL_STORAGE_SECRET_KEY
    ).toString(CryptoJS.enc.Utf8)

    // Return the data as an object if parse is true
    return parse ? JSON.parse(decryptedString || "") : decryptedString
  }

  return null
}

/**
 * Remove data from local storage by a key
 * @param key string
 */
export const removePersistedData = (key: string) => {
  localStorage.removeItem(key)
}

/**
 * Clear all data from local storage
 */
export const clearLocalStorage = () => {
  localStorage.clear()
}
