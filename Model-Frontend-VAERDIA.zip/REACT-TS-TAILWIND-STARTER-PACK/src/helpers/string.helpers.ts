export const getInitials = (str: string): string => {
  return str
    .split(" ")
    .map((n) => n.charAt(0))
    .join("")
}

export const toSnakeCase = (camelCaseString: string): string => {
  return camelCaseString.replace(/([A-Z])/g, "_$1").toLowerCase()
}
