import { matchPath } from "react-router-dom"

/**
 * Function to join paths
 * @param paths string[]
 * @param isAlreadyPath boolean
 * @returns string
 */
export const joinPaths = (paths: string[], isAlreadyPath?: boolean): string => {
  let joinedPath = ""
  for (const path of paths) {
    joinedPath += `${path}${!isAlreadyPath ? "/" : ""}`
  }
  return joinedPath
}

export const checkPathIsActive = (
  path: string,
  location: string,
  end = false
) => (path ? !!matchPath({ path, end }, location) : false)
