# React Project Template

##### React + TS + Vite + Tailwind CSS

This is the official **Vaerdia** React project template. It is designed for dashboard applications and includes minimal setup such as protected routes, layouts, and API integration. Clone it and you're ready to develop.

# Installation

We're using **Yarn** as the package manager. If you don't have it on your machine, you should install it first using the following command:

```sh
npm install -g yarn
```

Now you are good to go ✅✅

- **Clone the Project**: Start by cloning the project to your local machine.
- **Environment Setup**: At the project's root level, create a **.env** file. Inside this file, add the required environment variables. You will find the minimum required variables in the **.env.example** file. If you need to add a new one, keep in mind that the environment variables should always start with **VITE**. Don't forget to add it to the **.env.example** file as well 😅😄.
- **Install Dependencies**: Open your terminal and navigate to the project directory. Install all required dependencies by running `yarn install`.
- **Launch the Project** 🚀: Once the installation is complete, you can start the project by executing `yarn run dev` in your terminal.

# Folder Structure 🛑

React is so flexible, that every developer has its own way of organizing the project. However, to ensure that our projects are **scalable**, **maintainable**, and **easy to understand**, we’ve adopted a standardized folder structure. This structure is designed to keep the code organized and predictable, making it easier for any developer in our team to dive in, understand, and contribute effectively. Here’s a breakdown of our folder structure:

- **.husky** 🐶: This folder contains Git hooks that automate essential checks and improve code quality before changes are committed or pushed. We use two scripts here:
  - **pre-commit**: This hook automatically lints and formats code before it’s committed, ensuring consistent style and preventing syntax errors. By catching issues early, we reduce the risk of introducing code quality problems into the main branch.
  - **pre-push**: This hook builds the app before any code is pushed, which acts as a safeguard to ensure there are no issues with the build. This step prevents broken builds from reaching the remote branch, maintaining a reliable codebase for all developers.
- **public**: This folder contains static assets that are publicly accessible and don't require processing by Webpack or any bundler.
- **src**: This is the main folder and the heart of our application. It contains all the source code that drives the app’s functionality, from components and pages to services and utilities.
  - **assets**: Contains images, SVGs, icons, and other static assets used throughout the app.
  - **components**: Houses reusable, generic components like inputs, typography elements, containers, tables, cards, dialogs, and more. These components are designed to be versatile and can be used across various parts of the application.
  - **config**: Contains the application’s configuration files.
    - **config.ts**: This file imports environment variables, defines fallback values if certain variables are missing, and exports them. Using this file ensures consistent environment variable management and prevents the app from breaking due to missing variables.
    - **enums**: Holds enumerations used throughout the app.
    - **constants**: Stores application-wide constants, allowing for quick updates in one place.
  - **guards**: Contains route guards, such as `auth-guard` and `guest-guard`, which help protect specific routes based on user authentication status.
  - **helpers**: Stores globally needed helper functions (e.g., `string.helpers`, `date.helpers`, `path.helpers`). These functions provide utility operations used in multiple parts of the app.
  - **hooks**: Contains global custom hooks like `useDebounce`, `usePagination`, and `useLanguage`. If a hook is needed across different parts of the app, it should be defined here.
  - **lib**: Stores configurations for external libraries. For instance, custom configurations like an `axiosInstance` setup should be created here.
  - **locales**: Manages translation files, making the app accessible in different languages.
  - **pages**: Contains the different pages or views of the application, typically corresponding to the app’s route structure.
  - **routes**: Defines the app’s routes, centralizing navigation and helping with route management.
  - **store**: Manages globally shared state, facilitating state management across the app.
  - **types**: Contains type definitions and interfaces, with two main subfolders:
    - **models**: Defines main data models, such as `User`, `Product`, etc.
    - **interfaces**: Contains type definitions for API responses, pagination, table headers, and other types used throughout the app.

And last but not least the **features** folder. This is the core folder where all primary functionalities and domain-specific logic are organized. Each feature we interact with in the app has its own dedicated subfolder here. For instance, if you need to perform CRUD operations on products, you would create a products folder within features and include everything relevant to that feature—such as APIs, services, transformers, and any specific logic. I hope it's clear for you as it for me 😅, if not, don't worry you'll 💘 it.

Every subfolder should have these different subfolder

- **api**: Contains query and mutation hooks for performing API calls specific to this feature. This ensures that all API interactions are well-organized and easily accessible.
- **components**: Houses feature-specific components. These components are closely related to the feature and typically used only within its context.
- **schemas**: Defines validation schemas using Zod for forms related to the feature, ensuring data integrity and validation at the feature level.
- **services**: Contains asynchronous functions that call the APIs. These functions are imported into hooks within the api folder, keeping API logic separate and reusable.
- **transformers**: Contains decoder and encoder functions to transform request payloads or API responses, ensuring compatibility between frontend and backend expectations.
- **constants**: Stores constants specific to the feature. Centralizing these constants simplifies updates and ensures consistency within the feature.

These subfolders are essential for each feature, though additional folders (e.g., `helpers` for feature-specific helper functions or `hooks` for feature-specific custom hooks) can be added based on the needs of the feature.

I hope it's clear. I rely on you to respect this architecture 🤝🙏. If not, you will hove a hard time in code reviews 😅😄.

# Pre installed libraries

By default, this template comes with a set of carefully selected, pre-installed libraries. Each library has been chosen to ensure excellent TypeScript support and provide an outstanding developer experience.

- **React-Hook-Form**: Core library for managing form state and validation. Highly performant, works seamlessly with TypeScript, and enhances the developer experience by simplifying form handling. It minimizes re-renders, optimizes performance, and integrates well with schema validation libraries like Zod.
- **Zod**: A TypeScript-first schema declaration and validation library, allows you to define and validate your data structures with ease, ensuring type safety and catching errors early in development.
- **Zustand**: A lightweight, fast, and easy-to-use state management library that works seamlessly with React and TypeScript. It offers a simple API for managing global state, without the boilerplate typically associated with other state management solutions like Redux.
- **Lodash**: Set of utility functions for common programming tasks. Lodash simplifies operations such as deep cloning, manipulation of arrays, objects, and functions, and performing complex tasks like debouncing or throttling.
- **React-Use**: A collection of essential, reusable React hooks. It provides a wide range of hooks for common patterns like event handling, scrolling, lifecycle management and much more.
- **React-Qurey**:Simplifies data fetching, caching, synchronization, and state management for server-side data. It provides powerful hooks for handling API requests, automatically managing caching, background refetching, and error handling. It significantly improves the performance and reliability of applications by reducing the need for manual state management for remote data.
- **Date-fns**: A modern JavaScript date utility library that provides a comprehensive suite of functions to handle date and time operations in a lightweight, functional way. Chosen for its simplicity and performance.
- **Lucide-React** & **Radix-UI-Icons**: Provides a wide selection of crisp, customizable SVG and comprehensive set of icons. They work seamlessly with modern web applications.

# VS Code Setup and Extensions

Every developer has their own preferred setup and work environment, and I'm not here to change that 😊. However, I’d like to suggest a few extensions that you may or may not have already installed, which can significantly improve your productivity 🚀 and development experience ✌.

- **ESLint** and **Prettier**: Essential extensions for maintaining consistent code quality and formatting across the project.
- **GitLens** and **GitBlame**: Are powerful extensions that can greatly enhance your Git workflow and help you understand the history of your code.
- **Auto Close Tag** and **Auto Rename Tag**: two helpful extensions that improve your productivity when working with HTML, JSX, or XML files.
- **ES7+ React/Redux/React-Native snippets**: An essential extension that significantly boosts your development speed by providing a collection of handy code snippets for React, Redux, and React Native development.
- **React Hooks Snippets**: A handy extension that provides pre-defined code snippets for commonly used React hooks. It helps you quickly generate the code for various hooks like `useState`, `useEffect`, `useRef` and more.
- **Turbo Console Log**🚀: Useful extension that simplifies the process of adding `console.log()` statements for debugging in your JavaScript or TypeScript code.
- **Multiple cursor case preserve**: Useful tool for developers who work with multiple cursors in their code editor and need to preserve the case (uppercase or lowercase) of selected text while editing.
- **Total TypeScript**: Provides enhanced TypeScript support, offering a range of features designed to improve the developer experience when working with TypeScript code.
- **Template String Converter**: Simplifies working with template literals in JavaScript or TypeScript. It helps you quickly convert between regular strings and template strings, making it easier to manage string interpolation.
- **Code Spell Checker**: Designed to help developers identify and fix spelling mistakes in their code.
- **Tailwind CSS IntelliSense**: Designed to enhance the developer experience when working with Tailwind CSS. It provides intelligent suggestions, autocomplete, and quick access to documentation for all Tailwind utility classes, helping you write clean and efficient code faster.

These are the essential extensions that help ensure all developers have a consistent and productive setup, making it easier to collaborate and maintain a uniform development environment.

# Conslusion

Enough reading 📃. Go build something beautiful 😎
